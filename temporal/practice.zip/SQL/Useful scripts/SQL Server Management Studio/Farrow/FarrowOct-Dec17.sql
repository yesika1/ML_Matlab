select *
from csn_junk..tblFarrowOctober2017 oct17 with(nolock)

UNION

select *
from csn_junk..tblFarrowNovember2017 nov17 with (nolock)

UNION

select *
from csn_junk..tblFarrowDec2017Jan2018 with(nolock);