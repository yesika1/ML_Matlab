/*
----------------------------------------------------------------------------------
CUSTOMS INFORMATION - Index requested documents
----------------------------------------------------------------------------------
Use this script to retrieve custom information for a given transaction number
Input: User only needs to update the date and transaction number
server: sqlfinancero
*/

select 
--top 10 *
--from csn_junk.dbo.tblFarrow f with (nolock) 
--join csn_international..tblEDIOutItemIntl eii with (nolock)  on f.EiiOpID = eii.EiiOpID

distinct
f.EiiOpID  as 'OpID',
f.PONumber as 'PONumber',  
eii.EiiPrSku,  
SalesQty, 
CurrencyCode, ExchangeRate, CtryOrig,
Port_Num as 'Port of Clearance',
TransNum as 'Transaction Number',
'AB' as 'Entry Type',
K84Date as 'Accounting Date', --DsDate, K84Date ==43114 data stamp?
B3SubHeader as 'Subheader',
f.B3DtlLineNum as 'Line Number',
'2' as 'Tariff Treatment',
eii.EiiName as 'Description',
HSCode as 'Classification Number',
AdValoremDutyRate as 'Duty Rate',
VFCC as 'VFCC',
VFDAmt as ' VFD',
DutyAmt as 'Customs Duties', 
GSTAMT as 'GST'
--EoiPODate


from csn_junk.dbo.tblFarrow f with (nolock) 
join csn_international..tblEDIOutItemIntl eii with (nolock)  on f.EiiOpID = eii.EiiOpID
join csn_international..tblEDIOutIntl with (nolock) on eiieoiid = eoiid
where 
--eii.EiiPrSku in ('OHN3140', 'FTGX1031','NEWA1106', 'KTAX1944','IATI1071' )
--eii.EiiPrSku in ( 'KTAX1944','IATI1071' )
eii.EiiPrSku in ( 'KTAX1944' )

and EoiDateSent >= '1-1-2016' and EoiDateSent < '1-1-2020'
and EoiOkToSend = '1'

