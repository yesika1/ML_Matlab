#!/usr/bin/env python
# coding: utf-8

# ## Script to join SKU from case 0 and case 2

# In[1]:


import pandas as pd 


# In[2]:


file_description = r"T:\SalesAndOps\Logistics\International Supply Chain\Commercial Excellence\Compliance\Trade Compliance\Yesika's Files\Case_work_art\scripts\final_v0\case0_yes_SKU.csv"
file_hand_painted = r"T:\SalesAndOps\Logistics\International Supply Chain\Commercial Excellence\Compliance\Trade Compliance\Yesika's Files\Case_work_art\scripts\final_v0\case2_description_SKU.csv"


# In[3]:


data_description = pd.read_csv(file_description) 
data_hand_painted = pd.read_csv(file_hand_painted)

display(data_description.head(2))
display(data_hand_painted.head(2))

print(len(data_description))
print(len(data_hand_painted))


# In[4]:


# Stack the DataFrames on top of each other
vertical_stack = pd.concat([data_description, data_hand_painted], axis=0)
display(vertical_stack.head(2))
print('Joined file lenght:',len(vertical_stack))
print('Double checking output:',len(data_hand_painted)+len(data_description) )


# In[5]:


# removing duplicates
sku_grouped = vertical_stack.drop_duplicates()
print('Final SKU list lenght: ',len(sku_grouped))


# In[ ]:


## saving file
sku_grouped.to_csv(r"T:\SalesAndOps\Logistics\International Supply Chain\Commercial Excellence\Compliance\Trade Compliance\Yesika's Files\Case_work_art\scripts\final_v0\sku_grouped.csv")

