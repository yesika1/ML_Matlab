select DISTINCT
	 EiiPrSKU,
	 opPrSku,
	 op.opshipdate, 
	--pr.PrName,
	 eiiqty, 
	 EiiRetailPrice as 'VFD', 
	 EiiHsCode
from csn_order..tblorderproduct op with (nolock)
join csn_order..tblsupplier su with (nolock) on op.OpSuID=su.SuID
join csn_international..tblEDIOutItemIntl eii with (nolock) on op.OpID=eii.EiiOpID
join csn_international..tblEDIOutIntl eoi with (nolock) on eoi.EoiID=eii.EiiEoiID
--join csn_product..tblProduct pr with (nolock) on eii.eiiPrSKU=prSKU
where (opShipDate between '2017-01-01' and '2019-09-30') 
and op.OpReCyID = 2 
and su.SuStyID=1 
and op.OpPrPrice>1
and eoi.EoiOkToSend=1
and op.OpPrSKU in ('OHN3140','EJH1138','NEWA1106', 'FTGX1031')
ORDER BY op.OpShipDate
