/*
----------------------------------------------------------------------------------
 Script for pulling OpID, PO and Trans# for VFD investigation
----------------------------------------------------------------------------------
--csn_junk.dbo.FarrowDuty
the FarrowDuty table are the rows of data from both the doops and non-doops tables as of today (2/12/2020)

*/

/*
Select  FD.OpID, F.Trans#, OpShipDate, PONumber
from csn_junk.dbo.FarrowDuty FD
	Inner Join csn_junk.dbo.tblFarrow F
		ON FD.OpID = F.EiiOpID
Where  Month(OpShipdate) = 12 and day (opshipdate) = 2 and Year(OpShipdate) = 2016 

*/

--- Sample 10 items per month


declare @month as int, @year as int
set @month = 2
set @year = 2017
; --Insert date here


Select  TOP 10 FD.OpID, F.Trans#,  PONumber, '' as emptycol, B3DtlLine#, CAST(OpShipDate AS date) OpShipDate, DATENAME(month, OpShipDate) Month, YEAR (OpShipDate)  Year,
	iif( CHARINDEX('-', PONumber) >0 , SUBSTRING (PONumber,0,PATINDEX('%-%',PONumber)) , PONumber)  as PoNumberShort  --select characters before '-' when it is part of the string
from csn_junk.dbo.FarrowDuty FD
	Inner Join csn_junk.dbo.tblFarrow F
		ON FD.OpID = F.EiiOpID
Where  Month(OpShipdate) = @month and Year(OpShipdate) = @year
ORDER BY NEWID()
--*/

-- final table Audit 2017-2018
Select  TOP 10 *
from csn_junk.dbo.tblCanadaAudit20172018