/*
What we can join the tphs table on?

I would connect to tblproduct prhscodebase
as well as tblhscodecountry hscodecountry
so like a double join
tphs has a base and countrycode column


tblproduct stores the first 6 digits, tblhscodecountry stores the last 4
These will always be the current codes
*/

select 
--top 10 a.prsku, b.hscyid, c.TARIFF as hs_code, a.prhscodebase, b.hscodecountry, c.mfn
distinct c.TARIFF as hs_code, c.mfn as duty_rate

from csn_product..tblproduct a (nolock)
left join csn_product..tblhscodecountry b (nolock) on b.hsprsku = a.prsku
left join csn_shiprates..tphs c (nolock) on a.prhscodebase = c.hscodebase and b.hscodecountry = c.hscountrycode
where b.hscyid = 2
and a.prsku in('ERCC1048')
--and c.TARIFF in ('9701.10.97.01')
/*
c.TARIFF in ('5907.00.29.00',
'4911.91.00.20',
'9701.10.10.10',
'4911.91.00.90',
'4421.10.00.00',
'5907.00.21.00',
'4420.10.00.00',
'5901.90.90.00',
'5907.00.00.00',
'4421.99.90.90',
'4421.90.90.99',
'4419.90.00.00',
'8306.29.00.00',
'4420.90.00.90',
'4802.40.00.00',
'7616.99.90.90',
'9701.10.90.00',
'7326.90.90.90',
'4911.91.97.01',
'6913.90.90.00',
'7020.00.90.00',
'4802.54.00.00',
'3926.40.90.00',
'9701.10.97.01',
'9702.00.00.00',
'4414.00.00.90',
'4418.40.00.00',
'4814.20.00.00',
'4911.91.00.00',
'9701.90.90.00'
--'9701.10.10.10'

)
*/

--c.TARIFF in ('9701.10.10.10')
--a.prhscodebase in ('970110')
--c.TARIFF in ('5907.00.00.00')
--a.prhscodebase in ('590700')




