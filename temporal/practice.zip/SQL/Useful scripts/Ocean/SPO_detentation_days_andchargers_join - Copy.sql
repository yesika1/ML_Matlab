/*
Script retrieves how many days we had the container and how much we were charged

server: SQLREPORTING01
*/


select 
--distinct
--*
--right('wharfgateout_cw',11), as extractstring
d.SpoID, d.SupplierName, d.wharfgateout_cw as 'Wharf Gate Out'
--, emptycontainerreturn_cw
, d.emptycontainerreturn_master as 'Empty Cont. Return'
--datediff (day, d.wharfgateout_cw, d.emptycontainerreturn_master') as days_diff
, DATEDIFF (hour, d.wharfgateout_cw, d.emptycontainerreturn_master)/24 as days_diff
--LiPONumber as 'SPO'
,IiUnitPrice as 'DETENTION_CHRG_Unit_Price'
, LiTotalCost as 'DETENTION_CHRG_Total_Cost'

from
csn_export_scl.dbo.tblISCDatamart d with (nolock)
left join csn_invoice.dbo.tblLoadInvoice a with(nolock) on LiPONumber = SpoID
left join csn_invoice.dbo.tblLoadInvoiceItem b with(nolock) on a.[LiID] = b.[IiLiID]
--left join csn_reporting_isc.dbo.tblInboundSPOMilestones with (nolock) on LiPONumber = SpoID

where
[LiTsID] in ('562','725','999','1150','1152','1151', '1153', '1155', '544','695','790','934','944') and
IiUnitPrice <> '0'
--LiBOLNumber = '43854466'
--and LiPONumber = 'WHS-24819-4625766'
and IiDescription = 'DETENTION CHRG'
and SpoID = 'WHS-24819-4625766'

