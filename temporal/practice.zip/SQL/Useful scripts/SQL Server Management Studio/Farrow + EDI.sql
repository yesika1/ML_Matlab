select *
from csn_junk..tblFarrow f with(nolock)
where EiiOpID in ('2713590962')
ORDER BY EiiOpID ASC;
----------------------------------------------------------------
select *
from csn_international..tblEDIOutIntl eoi with(nolock)
join csn_international..tblEDIOutItemIntl eii with (nolock) on eoi.EoiID = eii.EiiEoiID

where EiiOpID in('2783291382')
and EoiOkToSend = '1'
ORDER BY EiiOpID ASC;
-----------------------------------------------------------------
/*select top 1*
from csn_international..tblEDIOutItemIntl with(nolock)

select top 1*
from csn_international..tblEDIOutIntl with(nolock);*/
----------------------------------------------------------------
select *
from csn_junk..tblFarrow f with (nolock)
join csn_international..tblEDIOutItemIntl eii with (nolock) on f.EiiOpID = eii.EiiOpID
left join csn_international..tblEDIOutIntl eoi with(nolock) on eoi.EoiID = eii.EiiEoiID

where eii.EiiOpID in('2783291382')
and EoiOkToSend = '1'