/*
Use this script to deep dive valuation and customs information for a given OpID.
First table shows basic price information
Second table (OpPiCost) shows the price of any add on's
Third and fourth tables (OdProductPromo and OaAmount) show any discounts
Fifth table (IntlFees) shows the total brokerage and duty estimates (what's deducted in VFD)
Sixth table (OpShippingLegs) shows the total freight estimate (what's deducted in VFD)
Seventh table (a few Eoi and Eii columns) shows the VFD sent to the broker
Eighth table (lots of Eii and Eoi columns) shows all the data sent to the broker
Ninth table (Amount) shows details of brokerage and duty estimates (ProductPriceTypeID=2 = duty; 3 = brokerage)
Tenth table (EstimatedCost) shows details of freight estimates
Eleventh table (CostInCuyID) shows the actual freight costs
Twelfth table (Sku) shows current product-related information
*/
declare @OpID as bigint
set @OpID = 2360067602

select OpCurrentPONum, OpPrPrice, OpQty, OpShipping, OpIntlOther, OpIntlShipping, OpIntlTax
/*
OpCurrentPONum
OpPrPrice (Column J - Base price of the product)
OpQty (Column C)
OpShipping (Column O - Shipping fee the customer pays - gets added to VFD)
OpIntlOther, OpIntlShipping, OpIntlTax (Add together in Column P - Various fees the customer pays - gets added to VFD)
*/
from csn_order..tblOrderproduct (nolock)
where OpID = @OpID;
select OpPiCost
from csn_order..tblorderproductoption (nolock)
/*
OpPiCost (Column K - add-on price the customer pays based on size, attribute, etc. - This is per unit)
*/
where OpID = @OpID;
select OdProductPromo
/*
OdProductPromo (Column M - discount)
*/
from csn_order..tblorderproductdetail (nolock)
where OdOpID = @OpID;
select OaDate, isnull(OaAmount,0) as OaAmount, OaDescription, OaTypeID
/*
OaAmount (Column N - More discounts - Negative indicates discount)
*/
from csn_order..tblorderadjustment (nolock)
where OaOpID = @OpID
order by OaDate Asc;
select 
/*
Column Q - Freight Costs - Add together "Shipping" Charges - use CostInCuyID unless it's in USD
Column R - Brokerage fee - When Carrier is Farrow/Bilsi and Charge=Brokerage or Priority Service
Column S - OGD (Other Government Dept fee) - When Carrier is Farrow/Bilsi and Charge=CFIA, SIMA
All subtracted from VFD
*/
OcOpID
,OcPoNum
,OcTsID
,case when OcTsID = '98' then 'Bilsi'
when OcTsID = '460' then 'Bison'
when OcTsID = '26' then 'FedExCA'
when OcTsID = '27' then 'UPSCA'
when OcTsID = '1' then 'UPSUS'
when OcTsID = '10' then 'FedExUS'
when OcTsID = '305' then 'AMJ'
when OcTsID = '46' then 'YRC'
when OcTsID = '352' then 'UPSLH'
when OcTsID in ('518','593') then 'NALG'
when OcTsID in ('161','594') then 'FastMile'
when OcTsID = '209' then 'Alero'
when OcTsID = '89' then 'NEMF'
when OcTsID = '129' then 'Cory'
when OcTsID = '343' then 'Western'
when OcTsID = '477' then 'Kore'
when OcTsID = '603' then 'Farrow'
when OcTsID = '630' then 'CHRobinson'
when OcTsID = '430' then 'Swift'
else 'New'
end as 'Carrier'
,case when (OcTsID = '98' and OcOtID = '3' and OcDescription <> 'Duty' and OcDescription <> 'CFIA') then 'Brokerage'
when OcTsID = '98' and OcOtID = '3' and OcDescription = 'Duty' then 'Duty'
when OcTsID = '98' and OcOtID = '4' and OcDescription = 'Taxes' then 'Tax'
when OcTsID = '98' and OcOtID = '3' and OcDescription = 'CFIA' then 'CFIA'
when OcTsID = '98' and OcOtID = '4' and OcDescription = 'HSTGST' then 'HSTGST'
when OcTsID = '603' and OcOtID = '3' and OcDescription = 'Customs Broker Fee' or OcDescription = 'Priority Service' then 'Brokerage'
when OcTsID = '603' and OcOtID = '3' and OcDescription <> 'Farrow Duty Credit' then 'Duty'
when OcTsID = '603' and OcOtID = '4' and OcDescription <> 'Goods and Services Tax Charge' then 'Taxes'
when OcTsID = '603' and OcOtID = '4' and OcDescription = 'Goods and Services Tax Charge' then 'HSTGST'
when OcTsID = '603' and OcOtID = '3' and OcDescription = 'Farrow Duty Credit' then 'CurrencyCorrection'
else 'Shipping'
end as 'Charge'
,sum(OcAmount) as 'CostInCuyID'
,OcCuyID
,sum(OcSubEntityCurrencyAmount) as 'CurrencyofTransaction'
from csn_cost..tblordercost a (nolock)
where OcOpID = @OpID and OcOtID != '1'
group by
OcOpID
,OcPoNum
,case when OcTsID = '98' then 'Bilsi'
when OcTsID = '460' then 'Bison'
when OcTsID = '26' then 'FedExCA'
when OcTsID = '27' then 'UPSCA'
when OcTsID = '1' then 'UPSUS'
when OcTsID = '10' then 'FedExUS'
when OcTsID = '305' then 'AMJ'
when OcTsID = '46' then 'YRC'
when OcTsID = '352' then 'UPSLH'
when OcTsID in ('518','593') then 'NALG'
when OcTsID in ('161','594') then 'FastMile'
when OcTsID = '209' then 'Alero'
when OcTsID = '89' then 'NEMF'
when OcTsID = '129' then 'Cory'
when OcTsID = '343' then 'Western'
when OcTsID = '477' then 'Kore'
when OcTsID = '603' then 'Farrow'
when OcTsID = '630' then 'CHRobinson'
when OcTsID = '430' then 'Swift'
else 'New'
end 
,case when (OcTsID = '98' and OcOtID = '3' and OcDescription <> 'Duty' and OcDescription <> 'CFIA') then 'Brokerage'
when OcTsID = '98' and OcOtID = '3' and OcDescription = 'Duty' then 'Duty'
when OcTsID = '98' and OcOtID = '4' and OcDescription = 'Taxes' then 'Tax'
when OcTsID = '98' and OcOtID = '3' and OcDescription = 'CFIA' then 'CFIA'
when OcTsID = '98' and OcOtID = '4' and OcDescription = 'HSTGST' then 'HSTGST'
when OcTsID = '603' and OcOtID = '3' and OcDescription = 'Customs Broker Fee' or OcDescription = 'Priority Service' then 'Brokerage'
when OcTsID = '603' and OcOtID = '3' and OcDescription <> 'Farrow Duty Credit' then 'Duty'
when OcTsID = '603' and OcOtID = '4' and OcDescription <> 'Goods and Services Tax Charge' then 'Taxes'
when OcTsID = '603' and OcOtID = '4' and OcDescription = 'Goods and Services Tax Charge' then 'HSTGST'
when OcTsID = '603' and OcOtID = '3' and OcDescription = 'Farrow Duty Credit' then 'CurrencyCorrection'
else 'Shipping'
end
,OcCuyID
,OcTsID 
select 
/* Nothing needed for audit report, but might be useful for troubleshooting
*/
 Op.OpPrSKU as 'Sku'
, p.PrName as 'ProductName'
, c.CyLongName as 'CountryofOrigin'
, ths.Tariff as 'HTSCode'
, ths.MFN as 'DutyRate'
, isnull(jpt.TryID,0) as 'NAFTAFlag'
from 
csn_order..tblorderproduct op (nolock)
join csn_product..tblproduct p (nolock) on op.OpPrSKU = p.PrSKU
join csn_product..tblplcountry c (nolock) on p.PrCyId = c.CyID
join csn_product..tblHSCodeCountry hs (nolock) on p.PrSKU=hs.HsPrSKU
join csn_shiprates..tphs ths (nolock) on p.PrHsCodeBase = ths.HSCodeBase and hs.HsCodeCountry=ths.HSCountryCode
left join csn_product..tbljoinProductTreaty jpt (nolock) on op.OpPrSKU=jpt.PrSku
where 
OpID = @OpID;