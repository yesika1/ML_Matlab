select top 2*
from csn_product.dbo.tblSupplier with(nolock);

select top 1*
from csn_product.dbo.tbljoinProductSupplier with(nolock);

select top 2*
;

select top 2*
from csn_international.dbo.tblEDIOutIntl with(nolock);

