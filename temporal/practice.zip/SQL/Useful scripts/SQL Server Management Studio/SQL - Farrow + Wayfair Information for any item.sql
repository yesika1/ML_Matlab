select DISTINCT * 
	
	
	/*EoiDateSent,
	EiiOpID,
	EiiRetailPrice,
	EiiQty,
	EiiPrSKU,
	EoiPONumSend,
	EiiName,
	EiiHSCode
	EoiDateSent*/
	
	
FROM csn_junk..tblFarrow f with(nolock)
join csn_international..tblEDIOutItemIntl eii with(nolock) on f.EiiOpID = eii.EiiOpID
join csn_international..tblEDIOutIntl eoi with(nolock) on eoi.EoiID = eii.EiiEoiID

WHERE EiiPrSKU in('DAN1392','EJH1138',
'FTGX1031')
and (eoi.EoiDateSent  between '2017-01-01' and '2019-12-31') 
and EoiOkToSend = '1'
ORDER BY EoiDateSent