/*
----------------------------------------------------------------------------------
Supplier Name
----------------------------------------------------------------------------------
Use this script to get supplier information: ID & name
Server: sqlBoadhoc
*/


select p.PrSKU, s.suid, s.SuName
from csn_product..tblproduct p with (nolock)
left join csn_product..tbljoinProductSupplier ps with (nolock) on p.prsku = ps.prsku
left join csn_product..tblsupplier s with (nolock) on ps.suid = s.suid 

where p.prsku = 'KTAX1943'