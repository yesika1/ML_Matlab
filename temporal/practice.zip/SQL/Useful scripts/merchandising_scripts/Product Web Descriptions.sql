/*
----------------------------------------------------------------------------------
PRODUCT WEB DESCRIPTION 
CASE 2. : Product description or Product Name being 'Hand Painted'
----------------------------------------------------------------------------------
Use this script to retrive a product SKU given the product  Stag Title/stag ID (which is unique for a ClID).
-- product active  prstatus = 4
-- pcid:
-- SuID:

-- For: 

-- output rows: 

*/


select 
--top 25 pcid, jpc.PrSKU, prname, PgenValue, cl.ClID, clinternalref, pr.SuID
 
distinct jpc.PrSKU,
pcid, prname, PgenValue, cl.ClID, clinternalref, pr.SuID


from 
csn_product..tbljoinproductclass jpc (nolock)
inner join csn_product..tblclass cl (nolock) on jpc.clid=cl.clid
inner join csn_product..tbljoinproductsupplier pr (nolock) on jpc.prsku=pr.prsku
inner join csn_product..tblproduct dog (nolock) on pr.prsku = dog.prsku
inner join csn_product..tblProductGenericTag d (nolock) on dog.Prsku=d.pgenprsku

where 
prbclgid in (1)  and pcmasterclass = 1 and jpc.clid = '1318'
--prbclgid in (1) and prstatus = 4 and pcmasterclass = 1 and jpc.clid = '1318'

and (prname like '%Hand%Painted%' or PgenValue like '%Hand%Painted%')

