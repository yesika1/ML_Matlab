 
 select top 2*
 from csn_product..tblHSCodeCountry hs with (nolock);

 select top 2*
 from csn_product..tblplcountry c with (nolock);


 select
	top 3
	h.HsPrSKU,
	h.HsCyId,
	c.CyLongName,
	e.EoiSupplierCountry,
	e.EoiBTCountry,
	e.EoiSTCountry,
	e.EoiSupplierName,
	e.EoiDateSent

from csn_product..tblHSCodeCountry h with (nolock)
join csn_product..tblPlCountry c with (nolock) on h.HsCyId = c.CyID
join csn_international.dbo.tblEDIOutIntl e with (nolock) on h.HsCyId = e.EoiSTCyID
where e.EoiDateSent BETWEEN '2019-09-01' AND '2019-09-30';