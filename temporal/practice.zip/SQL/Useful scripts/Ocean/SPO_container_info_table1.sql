/*
Ocen carrier -- container info
Here is script number 1. This is the base script that I would like BOL# pulled into as a new column. 
The table in this script only has SPO in it, not BOL#
server: SQLREPORTING01
*/


SELECT
SpoID as 'SPO',
gateinoriginport as "Wharf Gated In",
emptycontainerreturn_master as 'Empty Container Returned',
SpoInboundServiceLevelName as 'Service Level',
Suppliername as 'Supplier Name',
ContainerNumber as 'Container No.',
OceanCarrierName as 'Ocean Carrier',
DrayCarrierName as 'Dray Carrier',
OriginPortCode as 'Origin Port',
case when Originportcode = 'CNFZG' then 'China'
when Originportcode = 'CNFZH' then 'China'
when Originportcode = 'CNYTN' then 'China'
when Originportcode = 'CNSHG' then 'China'
when Originportcode = 'CNTAZ' then 'China'
when Originportcode = 'CNNBG' then 'China'
when Originportcode = 'CNTXG' then 'China'
when Originportcode = 'CNTYN' then 'China'
when Originportcode = 'CNWHG' then 'China'
when Originportcode = 'CNXAO' then 'China'
when Originportcode = 'CNXMG' then 'China'
when Originportcode = 'CNZPU' then 'China'
when Originportcode = 'CNZSN' then 'China'
when Originportcode = 'IDJKT' then 'Indonesia'
when Originportcode = 'IDSRG' then 'Indonesia'
when Originportcode = 'IDSUB' then 'Indonesia'
when Originportcode = 'INMUN' then 'India'
when Originportcode = 'INNSA' then 'India'
when Originportcode = 'MYPEN' then 'Malaysia'
when Originportcode = 'MYPGU' then 'Malaysia'
when Originportcode = 'MYPKG' then 'Malaysia'
when Originportcode = 'MYTPP' then 'Malaysia'
when Originportcode = 'THLCH' then 'Thailand'
when Originportcode = 'TWKHH' then 'Taiwan'
when Originportcode = 'TWTXG' then 'Taiwan'
when Originportcode = 'VNDAD' then 'Vietnam'
when Originportcode = 'VNIPH' then 'Vietnam'
when Originportcode = 'VNDNA' then 'Vietnam'
when Originportcode = 'VNSGN' then 'Vietnam'
when Originportcode = 'VNUIH' then 'Vietnam'
else 'Other'
end as 'Origin Country',
DestinationPortCode as 'Desination Port',
case when DestinationPortCode = 'USNYC' then 'US (EC)'
when DestinationPortCode = 'USSAV' then 'US (EC)'
when DestinationPortCode = 'USOAK' then 'US (WC)'
when DestinationPortCode = 'USORF' then 'US (EC)'
when DestinationPortCode = 'USLGB' then 'US (WC)'
when DestinationPortCode = 'USLAX' then 'US (WC)'
when DestinationPortCode = 'USJAX' then 'US (EC)'
when DestinationPortCode = 'USEWR' then 'US (EC)'
when DestinationPortCode = 'USDAL' then 'US (EC/WC)'
when DestinationPortCode = 'USCVG' then 'US (EC)'
when DestinationPortCode = 'GBSOU' then 'UK'
when DestinationPortCode = 'DEHAM' then 'Germany'
when DestinationPortCode = 'DEBRV' then 'Germany'
when DestinationPortCode = 'CATOR' then 'Canada'
else 'Other'
end as 'Destination Country',
DestinationWarehouse as 'Dest. Warehouse',
ContainerNumber as 'Container No.',
case when IsPrePull = '1' then 'Yes'
when IsPrePull = '0' then 'No'
else 'Other'
end as 'Pre-Pull'
FROM csn_export_scl.dbo.tblISCDatamart with (nolock)
where spoiscancelled = 0 and
SpoID = 'WHS-3026-5754265'

