select
	p.PrSKU,
	p.PrName,
	s.SuName,
	o.OpShipDate,
	o.OpSuID,
	o.OpReCyId,
	s.SuStyID

from csn_order.dbo.tblOrderProduct o with(nolock)
join csn_order..tblproduct p with(nolock) on o.OpPrSKU = p.PrSKU
join csn_order..tblSupplier s with(nolock) on o.OpSuID = s.SuID
where (o.OpShipDate BETWEEN '2019-09-01' AND '2019-09-30')
and o.OpReCyID = '2'
and s.SuStyID = '1'
ORDER BY o.OpShipDate ASC;