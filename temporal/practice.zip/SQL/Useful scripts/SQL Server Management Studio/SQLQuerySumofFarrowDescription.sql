SELECT 
OcDescription, sum(a.OcAmount)
--Count(OcDescription) AS farrow_rev
FROM csn_cost..tblOrderCost a with(nolock)
INNER JOIN csn_order..tblOrderProduct b with(nolock)
	ON a.OcOpID = b.OpID
WHERE b.OpShipDate BETWEEN '2017-10-01' AND '2017-10-31'
AND a.OcTsID = 603 
AND a.OcDescription NOT LIKE '%duty%'
GROUP BY OcDescription;