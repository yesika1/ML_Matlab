1. use supplier_name sql to retrieve the supplier ID & name

2. Use the Spec Sheet schemas.sql to retrieve the product literature

3. use the Product Web Descriptions.sql to retrieve the product literature too.

4. Use farrow_index.sql to fill the index requested docs excel file

5. To obtain the customer invoice:
Wayfair Admin Home - PO number in ORder Wizard & copy the customer_email
Wayfair.com -  Login with customer_email & go to My orders > look for SKU >view invoice > print PDF
In Adobe > open invoice > tools > redact > Mark for redaction > apply

6. Edit B3, B3 recap, CCI (Canada Customs Invoice) and BOL (Bill of Lading)
Select only pages with the Line number: in adobe > tools > organize pages > extract > save.
Highlight text as in previous submissions.
