/*
Log Changes in HS code

Per tyler: (2/25/2020) 
We started logging changes in the last year, 
but it can be a bit confusing to read because we only log changes to the last 4 digits
so you can see when it got changed to the current code
but cant really see what the old, full 10 digit code was - just the old last 4

*/

select top 10 * from csn_product..tblHsCodeCountryLog
where hslprsku in ('AA1000')