select 
OpCurrentPONum,
OpPrSKU
from
csn_order..tblOrderProduct op with(nolock)
where OpCurrentPONum in('88646934',
'88375942',
'88943711',
'88927873',
'88862161')

--ORDER BY OpPrSKU ASC; 

/*
select top 1*
from
csn_order..tblProduct with(nolock);

select top 1*
from csn_cost..tblOrderCost with(nolock);

csn_international..tblEDIOutItemIntl
*/