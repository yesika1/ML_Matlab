/*
----------------------------------------------------------------------------------
CUSTOMS INFORMATION WHEN OpID Split
----------------------------------------------------------------------------------

Use this script to deep dive valuation and customs information for a given OpID split.
Input: User needs to update the OpID value. This is the parent OpID

Outputs:

Server:
FYI this has to be run on the server sqlfinancero

*/

declare @OpID_parent as bigint
set @OpID_parent =  4112911019
; --Insert OpID here


Select OpID, OpSplitfromOpID, * from csn_order.dbo.tblOrderProduct
Where opsplitfromopid=@OpID_parent
--Where OPID in (select opid from csn_order.dbo.tblOrderProduct op with (nolock) where opsplitfromopid=@OpID_parent)

Select OpID, OpSplitFromOpID, OpShipDate, OpPrPrice, OpPiCost, OpShipping, OpQty, ProductPrice, Adjustments, ProductDetailPromo, BrokerageFees, ShippingCost, Replacement, VFD, Currency, F_VFCC, F_VFDAMT, F_DutyAMT, F_Duty, DutyFee,EmbeddedDuty, DutyAMt, Variance
from csn_junk.dbo.FarrowOpSplit
Where OpSplitFromOpID = @OpID_parent

Select *
from csn_junk.dbo.tblFarrow
Where EiiOPID in (select opid from csn_order.dbo.tblOrderProduct op with (nolock) where opsplitfromopid=@OpID_parent)