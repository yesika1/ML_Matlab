select 
chgid as 'chargeid', 
chgdate as 'date entered', 
fcsuid as 'suid', 
suname as 'supplier name', 
chgtotalamount as 'charge amount', 
chgcuyid as 'currency', 
chgdesc as 'charge type', 
case when chgadminadjustmentreasonid = 29 then 'drayage'
     when chgadminadjustmentreasonid = 32 then 'ocean' 
	 when chgadminadjustmentreasonid = 33 then 'asia' 
     else null end as 'charge type - detail',
ChgExternalNote 'full description',
chginvid as 'invoiceid', 
chgspoid as 'spoid', 
chgwhid as 'whid', 
wswhname as 'wh name',
emfirstname as 'first name - employee entered charges',
emlastname as 'last name - employee entered charges'
FROM csn_wfs.dbo.tblFulfillmentCustomerCharge fcc WITH (NOLOCK)
left join csn_wfs.dbo.tblFulfillmentCustomer with (nolock) on chgfcid = FcID 
left join csn_wfs.dbo.tblfulfillmentevent with (nolock) on evnid = chgevnid
left join csn_wfs..tblInvoice i with (nolock) on fcc.ChgInvID = i.InvID
left join csn_wms..tblwmssupplier with (nolock) on fcc.ChgWhid = wswhid
left join csn_order..tblsupplier with (nolock) on fcsuid = suid 
left join csn_hr..tblemployee with (nolock) on chgenterbyemid = Emid
--where chginvid = 17260
where chgspoid = 'WHS-6545-3479373'
