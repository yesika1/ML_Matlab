---Entering class: 

--- Pull up Microsoft SQL Server Management

--- Connect to Server: sqlboadhoc

---- DB Finder tool
https://admin.wayfair.com/v/db_info_tool/home


--Where to learn more?? Try the internet. https://www.w3schools.com/sql/
They have a great Quick Reference Guide


--LET'S PRACTICE BASIC SQL QUERIES 

--Example 1--Basic Select Query
select maid, maname, mastname
from csn_product..tblmanufacturer with (nolock)
where mastname= 'MA';


SELECT orid, orcompletedate, orsoid 
FROM csn_order..tblorder (nolock)
WHERE orsoid = 321 and orcompletedate > '2017-04-15';


--Example 2--Ordering Basic Select Query
select maid,maname,mastname
from csn_product..tblmanufacturer
with (nolock)
where mastname= 'MA'
Order by maname desc

--Operators: Use this after your 'where' or 'and' or 'or'
----   =           EQUAL     
----   <>          NOT EQUAL (can also use NOT)
----   >           Greater than 
----   <           Less than 
----   BETWEEN     Between an inclusive range (decide if you want to use this or > and <)
----   LIKE        Matching pattern
----   IN          Used instead of equal if multiple values
----   AND		   used to connect multiple operators

--Use Multiple Operators!
select prsku, prname
from csn_product..tblproduct
where PrSalePrice=119.00
and PrSKU='AAAT1085'


----Example 3-- Use Greater than (we will skip example 4)
select prsku, prname, prsaleprice
where prsaleprice > 119.00
from csn_product..tblproduct 


--EXERCISE!!!
/* Building off the example above, please expand on the query to find where the 
prsaleprice is greater than 119.00 and less than 120.00*/ 

----Use Between
select prsku, prname, prsaleprice
from csn_product..tblproduct with (nolock)
where prsaleprice between 119.00 and 120.00
Order by prsaleprice desc

----Use Equal
select prsku, prname, prsaleprice
from csn_product..tblproduct with (nolock)
Order by prsaleprice asc
where prsaleprice = 119.00 
And prsku like FIK%


--Use Not Equal
select prsku, prname, prsaleprice
from csn_product..tblproduct with (nolock)
where prsaleprice <> 119.00 
And prsku like 'FIK%'
Order by prsaleprice asc


---Example 5 -- See all columns & rows

Select * 
From csn_order..tblstore with (nolock)


---Example 6 -- See all columns, and you select rows

Select top 10 * 
From csn_order..tblstore with (nolock)

--See select columns and rows

Select top 10 soid, soname
From csn_order..tblstore with (nolock)
order by soname desc

--Example 7-- Apply conditions without viewing columns....

--Example 8 -- View specifc skus

select prsku
from csn_product..tblproduct with (nolock)
where left (prsku,3)= 'HML'

---same as
select prsku
from csn_product..tblproduct with (nolock)
where prsku like 'HML%'



--AGGREGATIONS!

Select Min(socaid)
from csn_order..tblstore (nolock)
--returns the smallest value in a given column

select socaid from csn_order..tblstore (nolock) where socaid= '0'

Select Max (socaid)
from csn_order..tblstore (nolock)
--returns the largest value in a given column

select socaid from csn_order..tblstore (nolock) 
Order by socaid desc


Select SUM (socaid)
from csn_order..tblstore (nolock)
--returns the sum of the numeric values in a given column

Select AVG(socaid)
from csn_order..tblstore (nolock)
--returns the average value of a given column


Select COUNT(socaid)
from csn_order..tblstore with (nolock)
--returns the total number of row in a given column
-- does not count the null values!

select * from csn_order..tblstore
where socaid is not Null ---311 rows


Select COUNT(*)socaid
from csn_order..tblstore with (nolock)
--returns the total number of row in a given column
--counts nulls too!

select * from csn_order..tblstore



