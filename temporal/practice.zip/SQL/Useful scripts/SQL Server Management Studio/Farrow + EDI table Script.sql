select top 1*
from csn_junk..tblFarrow f with(nolock) 
join csn_international..tblEDIOutItemIntl eii with(nolock) on f.EiiOpID = eii.EiiOpID
join csn_international..tblEDIOutIntl eoi with(nolock) on eii.EiiEoiID = eoi.EoiID
where eii.EiiOpID ='2556073321'
and EiiPrSKU = 'ESIG1148'
and EoiOkToSend = '1';