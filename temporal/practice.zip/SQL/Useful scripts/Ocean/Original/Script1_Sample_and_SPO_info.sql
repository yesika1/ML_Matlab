/*
Script 1: Sample & SPO info

- Given a date in where clause:
This script pulls SPOs that had containers returned empty to the port 
between a given number of months in a year.
Set the year and months in the where clause: EmptyContainerReturn_Master
Used to get a sample

- Given a spo in where clause:
This script pull an SPO and accompanying shipment information		

Database:SQLREPORTING01
Updated:	4/22/20	4:35 PM	
*/
-------------------------------------------------------------------------------

SELECT
SpoID as 'SPO',
emptycontainerreturn_master as 'Empty Container Returned',
SpoInboundServiceLevelName as 'Service Level',
OceanCarrierName as 'Ocean Carrier',
DrayCarrierName as 'Dray Carrier',
OriginPortCode as 'Origin Port',
case when Originportcode = 'CNFZG' then 'China'
when Originportcode = 'CNFZH' then 'China'
when Originportcode = 'CNYTN' then 'China'
when Originportcode = 'CNSHG' then 'China'
when Originportcode = 'CNTAZ' then 'China'
when Originportcode = 'CNTXG' then 'China'
when Originportcode = 'CNTYN' then 'China'
when Originportcode = 'CNWHG' then 'China'
when Originportcode = 'CNXAO' then 'China'
when Originportcode = 'CNXMG' then 'China'
when Originportcode = 'CNZPU' then 'China'
when Originportcode = 'CNZSN' then 'China'
when Originportcode = 'IDJKT' then 'Indonesia'
when Originportcode = 'IDSRG' then 'Indonesia'
when Originportcode = 'IDSUB' then 'Indonesia'
when Originportcode = 'INMUN' then 'India'
when Originportcode = 'INNSA' then 'India'
when Originportcode = 'MYPEN' then 'Malaysia'
when Originportcode = 'MYPGU' then 'Malaysia'
when Originportcode = 'MYPKG' then 'Malaysia'
when Originportcode = 'MYTPP' then 'Malaysia'
when Originportcode = 'THLCH' then 'Thailand'
when Originportcode = 'TWKHH' then 'Taiwan'
when Originportcode = 'TWTXG' then 'Taiwan'
when Originportcode = 'VNDAD' then 'Vietnam'
when Originportcode = 'VNSGN' then 'Vietnam'
when Originportcode = 'VNUIH' then 'Vietnam'
else 'Other'
end as 'Origin Country',
DestinationPortCode as 'Desination Port',
case when DestinationPortCode = 'USNYC' then 'US'
when DestinationPortCode = 'USSAV' then 'US'
when DestinationPortCode = 'USOAK' then 'US'
when DestinationPortCode = 'USORF' then 'US'
when DestinationPortCode = 'USLGB' then 'US'
when DestinationPortCode = 'USLAX' then 'US'
when DestinationPortCode = 'USJAX' then 'US'
when DestinationPortCode = 'USEWR' then 'US'
when DestinationPortCode = 'USDAL' then 'US'
when DestinationPortCode = 'USCVG' then 'US'
when DestinationPortCode = 'GBSOU' then 'UK'
when DestinationPortCode = 'DEHAM' then 'Germany'
when DestinationPortCode = 'DEBRV' then 'Germany'
when DestinationPortCode = 'CATOR' then 'Canada'
else 'Other'
end as 'Destination Country',
DestinationWarehouse as 'Dest. Warehouse',
ContainerNumber as 'Container No.',
case when IsPrePull = '1' then 'Yes'
when IsPrePull = '0' then 'No'
else 'Other'
end as 'Pre-Pull'
FROM csn_export_scl.dbo.tblISCDatamart
where 
spoiscancelled = 0 

-- Given a date - Sample:
------------------
--and not spoinboundservicelevelname = 'NRV'
--and spoinboundservicelevelname in ('NVO')	
--and EmptyContainerReturn_Master >=  '20200101' and EmptyContainerReturn_Master < '20200401'
--and EmptyContainerReturn_Master between '2020-01-01 00:00:00' and '2020-03-31 23:59:59' 
--order by emptycontainerreturn_master asc



-- Given an SpoID:
------------------
and SpoID = 'WHS-3026-5754265'



