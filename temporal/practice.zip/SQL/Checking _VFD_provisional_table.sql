

/*
-- Create new table: 
SELECT * INTO <newtable> FROM <oldtable>

-- Views vs. with clause:
SQL-92 introduced views to make queries reusable. Once created, a view has a name in the database schema so that other queries can use it like a table.

SQL:1999 added the with clause to define �statement scoped views�. They are not stored in the database schema: 
instead, they are only valid in the query they belong to. 
This makes it possible to improve the structure of a statement without polluting the global namespace.

WITH query_name1 (tempcol1, temcoln) AS (
     SELECT ...
     )
   , query_name2 (tempcol1, temcoln) AS (
     SELECT ...
       FROM query_name1
        ...
     )
SELECT ...

-- Sub queries in From Clause:
The sub-query in the from clause is evaluated first and then the results of evaluation are stored in a new temporary relation.
Next, the outer query is evaluated, selecting only those tuples from the temporary relation that satisfies the predicate in the where clause of the outer query.

SELECT column1, column2 FROM 
(SELECT column_x  as C1, column_y FROM table WHERE PREDICATE_X)
as table2
WHERE PREDICATE;
*/



With AccountingDate_t (OpID, AccountingDate, Port#, HsCode, Trans#, B3SubHeader)
As (Select EiiOpID, Min(K84Date), Min(Port#), Min(HsCode), MIN(Trans#), min(B3SubHeader)
	From csn_junk.dbo.FarrowAudit
	Group By EiiOpID)
--Update #F
--set AccountingDate = '2/21/2017'
--Where OpID = 2500415081
Select Distinct T.OpID, ad.Port#, ad.Trans#, 'AB' as EntryType, AccountingDate as AccountingDate, 
	ad.B3SubHeader, 
	Case When B3Line is not Null then B3Line Else B3DtlLine# end as B3Line, 
	2 as TariffTreatment, PrName, ad.HScode, F_VFCC, F.VFDAMT, F_VFDAMt, F_Duty, F_DutyAMT
--, Round(Cast(GSTAMT as float),1) as F_GSTAMT,
,F_Duty as Duty, Round(VFD,2) as VFD, Round(T.DutyAmt,2) as DutyAmt, T.Variance
into  #F
from csn_junk.dbo.FarrowDutyTariq T
	Inner Join AccountingDate_t AD
		ON AD.OpID = T.OpID
	Left Join csn_junk.dbo.FarrowAudit F
		ON F.EiiOpID = T.OpID
	Inner Join csn_order.dbo.tblOrderProduct OP
		ON Op.OPID = T.OpID
	Inner Join csn_product.dbo.tblProduct P
		ON P.PrSKU = Op.OpPrSKU
Where T.OpShipDate >= '1/1/2018' and T.OpShipDate < '1/1/2019'
--and T.OpID = 8159658700
Order By Variance


select top 10 *
from #F
where  OpID =2923186929

