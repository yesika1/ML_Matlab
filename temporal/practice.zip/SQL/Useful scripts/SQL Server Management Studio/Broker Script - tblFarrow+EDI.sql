select top 1*
from csn_international..tblEDIOutIntl with(nolock);

select top 1*
from csn_international..tblEDIOutItemIntl with(nolock);

select top 1*
from csn_junk..tblFarrow with(nolock);

/*select 
	EiiOpID,
	EiiPrSKU,
	EiiName,
	
from csn_international..tblEDIOutItemIntl eii with(nolock)
join csn_international..tblEDIOutIntl eoi with(nolock) on */

select 
	f.Trans#,
	f.PONumber,
	eii.EiiOpID,
	HSCode,
	eii.EiiPrSKU,
	eii.EiiName,
	eoi.EoiOkToSend

from csn_junk..tblFarrow f with (nolock)
join csn_international..tblEDIOutIntl eoi with(nolock) ON f.EoiPoNum = eoi.EoiPONum
join csn_international..tblEDIOutItemIntl eii with(nolock) on eii.EiiEoiID = eoi.EoiID

where 
eii.EiiOpID in ()
and EoiOkToSend = 1