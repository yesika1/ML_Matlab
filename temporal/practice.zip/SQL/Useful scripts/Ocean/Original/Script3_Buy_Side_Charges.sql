/*
Script 3: Buy-Side Charges
Accounts Payable

This script pulls IPS charge information for a given SPO.								
Notes: Evergreen charges go through CargoSprint, not IPS. 
For Evergreen charges, use "CARGOSPRINT TRACKER" in Google Drive.
Other ocean carriers may not have charges appearing in IPS prior to mid-March.								

Database:	SQLREPORTING02				
Updated:	4/24/20	6:08 PM	
*/
-------------------------------------------------------------------------------								
								
select distinct		
a.LiTsID		
,LiPONumber as 'SPO'		
,LiBOLNumber as 'BOL No.'		
,LiContainerNumber as 'Container No.'		
,OceanCarrier as 'Ocean Carrier'		
,DrayTsName as 'Dray Carrier'		
,LiDateCreated as 'Invoice Entry Created'		
--,liinvoicedate as 'Date Invoiced'		
--,LiDateLoaded as 'Date Loaded'		
,LiStatus as 'Status'		
,LiInvoiceNumber as 'Invoice No.'	
,IiDescription as 'Charge Description'		
--,IiRatedCost		
,IiDescrCode as 'Desc. Code'	
,IiUnitPrice as 'Unit Price'	
,LiTotalCost as 'Total Vendor Cost'	
,DestinationWarehouse as 'Destination WH'		
	
from		
csn_invoice.dbo.tblLoadInvoice a with(nolock)		
join csn_invoice.dbo.tblLoadInvoiceItem b with(nolock) on a.[LiID] = b.[IiLiID]		
left join csn_reporting_isc.dbo.tblInboundSPOMilestones with (nolock) on LiPONumber = SpoID		
--join csn_invoice.dbo.tblInvoiceWeatherTrackingLog I WITH (NOLOCK) on I.LiID = a.LiID		
--INNER JOIN csn_invoice.dbo.tblplInvoiceWeatherAction c WITH (NOLOCK) on c.ActionID = I.ActionID		
where		
[LiTsID] in ('562','725','999','1150','1152','1151', '1153', '1155', '544','695','790','934','944')		
and IiUnitPrice <> '0'	
and LiStatus = 'C'	
and LiPONumber = 'WHS-3026-6013211'		
--and LiBOLNumber = 'WUH191239628'		
or LiBOLNumber = 'JK1191254833'		
ORDER BY Listatus, LiDateCreated ASC									