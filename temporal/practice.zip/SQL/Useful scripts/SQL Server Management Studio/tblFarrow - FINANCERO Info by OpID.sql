select Tr
from csn_junk..tblFarrow with(nolock)
where EiiOpID = '2884564371'
