select
	EoiDateSent,
	EoiPONum,
	EiiOpID,
	EiiPrSKU,
	EiiName
	
FROM csn_international..tblEDIOutItemIntl eii with(nolock)
join csn_international..tblEDIOutIntl eoi with(nolock) on eoi.EoiID = eii.EiiEoiID

WHERE 
--EoiDateSent BETWEEN '2015-01-01' and '2019-10-01'
 EiiPrSKU in
('HW1383',
'HEF1138',
'UH1847',
'YDCR1135',
'BCHH8112',
'OAWY2985',
'ASTG5092',
'GDRD1001')

ORDER BY EiiPrSKU;
