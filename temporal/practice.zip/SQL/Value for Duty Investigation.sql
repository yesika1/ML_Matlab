/*
Use this script to deep dive valuation and customs information for a given OpID.

First table shows basic price information
Second table (OpPiCost) shows the price of any add on's
Third and fourth tables (OdProductPromo and OaAmount) show any discounts
Fifth table (IntlFees) shows the total brokerage and duty estimates (what's deducted in VFD)
Sixth table (OpShippingLegs) shows the total freight estimate (what's deducted in VFD)
Seventh table (a few Eoi and Eii columns) shows the VFD sent to the broker
Eighth table (lots of Eii and Eoi columns) shows all the data sent to the broker
Ninth table (Amount) shows details of brokerage and duty estimates (ProductPriceTypeID=2 = duty; 3 = brokerage)
Tenth table (EstimatedCost) shows details of freight estimates
Eleventh table (CostInCuyID) shows the actual freight costs
Twelfth table (Sku) shows current product-related information

Server:
FYI this has to be run on the server sqlorderro

*/


declare @OpID as bigint
set @OpID = 8179467590; --Insert OpID here

select OpCurrentPONum, OpPrPrice, OpQty, OpShipping, OpIntlOther, OpIntlShipping, OpIntlTax
from csn_order..tblOrderproduct (nolock)
where OpID = @OpID;

select OpPiCost
from csn_order..tblorderproductoption (nolock)
where OpID = @OpID;

select OdProductPromo
from csn_order..tblorderproductdetail (nolock)
where OdOpID = @OpID;

select OaDate, isnull(OaAmount,0) as OaAmount, OaDescription, OaTypeID
from csn_order..tblorderadjustment (nolock)
where OaOpID = @OpID
order by OaDate Asc;

select sum(Amount) as 'IntlFees'
from csn_order..tblorderproductprice (nolock)
where ProductPriceTypeID in ('2','3') and OpID = @OpID;

select sum(EstimatedCost) as 'OpShippingLegs'
from csn_order..tblorderproductshippinglegs (nolock)
where OpID = @OpID;

select EoiDateSent, EiiRetailPrice, EiiQty
from csn_international..tblEDIOutItemIntl with (nolock)
join csn_international..tblEDIOutIntl with (nolock) on EoiID=EiiEoiID
join csn_international..tblEDIOutBolIntl with (nolock) on EoiEbiID=EbiID
where 
EoiOkToSend = '1' --and EbiDateSent is not null
and EiiOpID = @OpID

select *
from csn_international..tblEDIOutItemIntl with (nolock)
join csn_international..tblEDIOutIntl with (nolock) on EoiID=EiiEoiID
where EiiOpID = @OpID;

select *
from csn_order..tblorderproductprice (nolock)
where ProductPriceTypeID in ('2','3') and OpID = @OpID;

select *
from csn_order..tblorderproductshippinglegs (nolock)
where OpID = @OpID;

select 
OcOpID, OcOtID
,OcPoNum
,OcTsID
,case when OcTsID = '98' then 'Bilsi'
when OcTsID = '460' then 'Bison'
when OcTsID = '26' then 'FedExCA'
when OcTsID = '27' then 'UPSCA'
when OcTsID = '1' then 'UPSUS'
when OcTsID = '10' then 'FedExUS'
when OcTsID = '305' then 'AMJ'
when OcTsID = '46' then 'YRC'
when OcTsID = '352' then 'UPSLH'
when OcTsID in ('518','593') then 'NALG'
when OcTsID in ('161','594') then 'FastMile'
when OcTsID = '209' then 'Alero'
when OcTsID = '89' then 'NEMF'
when OcTsID = '129' then 'Cory'
when OcTsID = '343' then 'Western'
when OcTsID = '477' then 'Kore'
when OcTsID = '603' then 'Farrow'
when OcTsID = '630' then 'CHRobinson'
when OcTsID = '430' then 'Swift'
else 'New'
end as 'Carrier'
,case when (OcTsID = '98' and OcOtID = '3' and OcDescription <> 'Duty' and OcDescription <> 'CFIA') then 'Brokerage'
when OcTsID = '98' and OcOtID = '3' and OcDescription = 'Duty' then 'Duty'
when OcTsID = '98' and OcOtID = '4' and OcDescription = 'Taxes' then 'Tax'
when OcTsID = '98' and OcOtID = '3' and OcDescription = 'CFIA' then 'CFIA'
when OcTsID = '98' and OcOtID = '4' and OcDescription = 'HSTGST' then 'HSTGST'
when OcTsID = '603' and OcOtID = '3' and OcDescription = 'Customs Broker Fee' or OcDescription = 'Priority Service' then 'Brokerage'
when OcTsID = '603' and OcOtID = '3' and OcDescription <> 'Farrow Duty Credit' then 'Duty'
when OcTsID = '603' and OcOtID = '4' and OcDescription <> 'Goods and Services Tax Charge' then 'Taxes'
when OcTsID = '603' and OcOtID = '4' and OcDescription = 'Goods and Services Tax Charge' then 'HSTGST'
when OcTsID = '603' and OcOtID = '3' and OcDescription = 'Farrow Duty Credit' then 'CurrencyCorrection'
else 'Shipping'
end as 'Charge'
,sum(OcAmount) as 'CostInCuyID'
,OcCuyID
,sum(OcSubEntityCurrencyAmount) as 'RealCostinCAD'
from csn_cost..tblordercost a (nolock)
where OcOpID = @OpID and OcOtID in (2,3)
group by
OcOpID, OcOtID
,OcPoNum
,case when OcTsID = '98' then 'Bilsi'
when OcTsID = '460' then 'Bison'
when OcTsID = '26' then 'FedExCA'
when OcTsID = '27' then 'UPSCA'
when OcTsID = '1' then 'UPSUS'
when OcTsID = '10' then 'FedExUS'
when OcTsID = '305' then 'AMJ'
when OcTsID = '46' then 'YRC'
when OcTsID = '352' then 'UPSLH'
when OcTsID in ('518','593') then 'NALG'
when OcTsID in ('161','594') then 'FastMile'
when OcTsID = '209' then 'Alero'
when OcTsID = '89' then 'NEMF'
when OcTsID = '129' then 'Cory'
when OcTsID = '343' then 'Western'
when OcTsID = '477' then 'Kore'
when OcTsID = '603' then 'Farrow'
when OcTsID = '630' then 'CHRobinson'
when OcTsID = '430' then 'Swift'
else 'New'
end 
,case when (OcTsID = '98' and OcOtID = '3' and OcDescription <> 'Duty' and OcDescription <> 'CFIA') then 'Brokerage'
when OcTsID = '98' and OcOtID = '3' and OcDescription = 'Duty' then 'Duty'
when OcTsID = '98' and OcOtID = '4' and OcDescription = 'Taxes' then 'Tax'
when OcTsID = '98' and OcOtID = '3' and OcDescription = 'CFIA' then 'CFIA'
when OcTsID = '98' and OcOtID = '4' and OcDescription = 'HSTGST' then 'HSTGST'
when OcTsID = '603' and OcOtID = '3' and OcDescription = 'Customs Broker Fee' or OcDescription = 'Priority Service' then 'Brokerage'
when OcTsID = '603' and OcOtID = '3' and OcDescription <> 'Farrow Duty Credit' then 'Duty'
when OcTsID = '603' and OcOtID = '4' and OcDescription <> 'Goods and Services Tax Charge' then 'Taxes'
when OcTsID = '603' and OcOtID = '4' and OcDescription = 'Goods and Services Tax Charge' then 'HSTGST'
when OcTsID = '603' and OcOtID = '3' and OcDescription = 'Farrow Duty Credit' then 'CurrencyCorrection'
else 'Shipping'
end
,OcCuyID
,OcTsID 

select 
 Op.OpPrSKU as 'Sku'
, p.PrName as 'ProductName'
, c.CyLongName as 'CountryofOrigin'
, ths.Tariff as 'HTSCode'
, ths.MFN as 'DutyRate'
, isnull(jpt.TryID,0) as 'NAFTAFlag'
from 
csn_order..tblorderproduct op (nolock)
join csn_product..tblproduct p (nolock) on op.OpPrSKU = p.PrSKU
join csn_product..tblplcountry c (nolock) on p.PrCyId = c.CyID
join csn_product..tblHSCodeCountry hs (nolock) on p.PrSKU=hs.HsPrSKU
join csn_shiprates..tphs ths (nolock) on p.PrHsCodeBase = ths.HSCodeBase and hs.HsCodeCountry=ths.HSCountryCode
left join csn_product..tbljoinProductTreaty jpt (nolock) on op.OpPrSKU=jpt.PrSku
where 
OpID = @OpID;
