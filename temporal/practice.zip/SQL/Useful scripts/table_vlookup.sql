/*
----------------------------------------------------------------------------------
TABLE FINDER GIVEN OpID
----------------------------------------------------------------------------------
Use this script to access to the table information in the VFD investigation for a given OpID.

Input:
put OpID in and it will pull the data elements from all three tables (doops, nondoops, OpSplit) so you can see which table is the correct one for that OpID

Output:
Data will be displayed on the corresponding table, where:
Table 1: OpSplit
Table 2: Doops
Table 3: NonDoops
Data can be copied directly into the excel file

Server:
FYI this has to be run on the server sqlfinancero
*/

declare @OpID as bigint
set @OpID = 2718841792
; --Insert OpID here


Select top 10 OpID, Adjustments, B3Line, BrokerageFees, Currency, OpSOID,OpShipDate, DutyAmt, EiiNAFTA, EmbeddedDuty, F_DutyAMT, F_Duty, F_VFCC, F_VFDAMT, OGDFees, ShippingCost, OpPiCost, OpPrPrice, ProductPrice, ProductDetailPromo, OpQty, OpShipping, VFD, variance, WarrantyPrice, OpSplitFromOpID
from csn_junk.dbo.FarrowOpSplit with (nolock)
where OpID = @OpID;
--where OPID in ('')

select top 10 OpID, Adjustments, B3Line, BrokerageFees, Currency, OpSOID,OpShipDate, DutyAmt, EiiNAFTA, EmbeddedDuty, F_DutyAMT, F_Duty, F_VFCC, F_VFDAMT, OGDFees, ShippingCost, OpPiCost, OpPrPrice, ProductPrice, ProductDetailPromo, OpQty, OpShipping, VFD, variance, WarrantyPrice
from csn_junk..FarrowDoops2 with (nolock)
where OpID = @OpID;
--where OPID in ('')

select top 10 OpID, Adjustments, B3Line, BrokerageFees, Currency, OpSOID,OpShipDate, DutyAmt, EiiNAFTA, EmbeddedDuty, F_DutyAMT, F_Duty, F_VFCC, F_VFDAMT, OGDFees, ShippingCost, OpPiCost, OpPrPrice, ProductPrice, ProductDetailPromo, OpQty, OpShipping, VFD, variance, WarrantyPrice
 from csn_junk..FarrowNonDoops2 with (nolock)
where OpID = @OpID;
--where OPID in ('')

