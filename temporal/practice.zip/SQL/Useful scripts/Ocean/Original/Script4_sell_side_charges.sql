/*
Script 4: Sell-side charges
This script pulls sell-side charges for a given SPO from the Extranet.								

Database:	SQLREPORTING01				
Updated:	4/24/20	9:58 AM	
*/								
-------------------------------------------------------------------------------								
								
select								
chgdate as 'date entered',								
fcsuid as 'suid',								
suname as 'supplier name',								
chgtotalamount as 'charge amount',								
chgcuyid as 'currency',								
chgdesc as 'charge type',								
case when chgadminadjustmentreasonid = 29 then 'drayage'								
when chgadminadjustmentreasonid = 32 then 'ocean'								
when chgadminadjustmentreasonid = 33 then 'asia'								
else null end as 'charge type - detail',								
case								
when ChgExternalNote like '%Port Congestion%' then 'Congestion'								
when ChgExternalNote like 'Drayage Charge%' and chgadminadjustmentreasonid = 29 then 'Dray Base Rate'								
when ChgExternalNote like  '%Container Drayage%'and chgadminadjustmentreasonid = 29 then 'Dray Base Rate'								
when ChgExternalNote like  '%Base Rate%' and chgadminadjustmentreasonid = 29 then 'Dray Base Rate'								
when ChgExternalNote like  '%Base%' and chgadminadjustmentreasonid = 29 then 'Dray Base Rate'								
--when ChgExternalNote like 'Drayage Charge%' and chgadminadjustmentreasonid = 32 then 'Ocean Base Rate'								
--when ChgExternalNote like 'Container Drayage%' then 'Base Rate'								
when ChgExternalNote like '%Base Rate%'  and chgadminadjustmentreasonid = 32 then 'Ocean Base Rate'								
when ChgExternalNote like '%Base%' and chgadminadjustmentreasonid = 32 then 'Ocean Base Rate'								
when ChgExternalNote like '%Bunker%' then 'Bunker'								
when ChgExternalNote like '%Document%' then 'DDOC'								
when ChgExternalNote like '%Peak%' then 'PSS'								
when ChgExternalNote like '%fuel%' then 'Dray Fuel'								
when ChgExternalNote like '%Pier%' then 'Pier Pass'								
when ChgExternalNote like '%Security%' then 'Security Fee'								
when ChgExternalNote like '%AMS%' then 'AMS Filing Fee'								
when ChgExternalNote like '%Exam%' then 'Exam'								
else 'Other'								
end as 'Charge',								
ChgExternalNote 'full description',								
chginvid as 'invoiceid',								
chgspoid as 'spoid',								
chgwhid as 'whid',								
wswhname as 'wh name',								
emfirstname as 'first name - employee entered charges',								
emlastname as 'last name - employee entered charges'								
FROM csn_wfs.dbo.tblFulfillmentCustomerCharge fcc WITH (NOLOCK)								
left join csn_wfs.dbo.tblFulfillmentCustomer with (nolock) on chgfcid = FcID								
left join csn_wfs.dbo.tblfulfillmentevent with (nolock) on evnid = chgevnid								
left join csn_wfs..tblInvoice i with (nolock) on fcc.ChgInvID = i.InvID								
left join csn_wms..tblwmssupplier with (nolock) on fcc.ChgWhid = wswhid								
left join csn_order..tblsupplier with (nolock) on fcsuid = suid								
left join csn_hr..tblemployee with (nolock) on chgenterbyemid = Emid								
where								
--fcsuid = 868								
--and chgdesc like '%Admin%'								
--and chgadminadjustmentreasonid = 29								
--where chginvid = 17260								
chgspoid = 'WHS-3026-5754265'								
order by chgadminadjustmentreasonid desc								