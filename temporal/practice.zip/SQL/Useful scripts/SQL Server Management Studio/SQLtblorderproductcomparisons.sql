select top 3*
from csn_reporting.dbo.tblOrderProductMetrics with(nolock);

select top 3*
from csn_order.dbo.tblOrder with(nolock);

select top 2*
from csn_product.dbo.tblProduct with(nolock);

select top 2*
from csn_order.dbo.tblOrderProduct with(nolock);

select
 p.prSKU,
 p.PrName, 
 c.CyLongName as 'CountryOfOrigin',
 hs.HsCyId, 
 tphs.TARIFF,
 tphs.MFN as 'MFNDutyRate',
 o.OpReCountry,
 jpt.TryID
from csn_product..tblproduct p with (nolock)
join csn_product..tblplcountry c with (nolock) on p.PrCyId = c.CyID
join csn_product..tblHSCodeCountry hs with (nolock) on p.PrSKU=hs.HsPrSKU
join csn_order.dbo.tblOrderProduct o with(nolock) on p.PrSKU = o.OpPrSKU
join csn_shiprates..tphs tphs with (nolock) on p.PrHsCodeBase = tphs.HSCodeBase and hs.HsCodeCountry=tphs.HSCountryCode
left join csn_product..tbljoinProductTreaty jpt with (nolock) on p.PrSKU=jpt.PrSku
where hs.HsCyId=2 and c.CyLongName = 'United States'and o.OpReCountry = 'Canada';
