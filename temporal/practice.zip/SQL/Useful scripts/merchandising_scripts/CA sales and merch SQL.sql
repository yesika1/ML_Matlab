select distinct top 500
EiiPrSku,
EiiHsCode,

cl.ClID,
count(EoiPONumSend) as Po_Count

from
csn_international..tblEDIOutItemIntl eii with (nolock) 
join csn_international..tblEDIOutIntl with (nolock) on eiieoiid = eoiid
--------
--left join tblProduct p WITH(NOLOCK) on eiiprsku = p.prsku

--left join  csn_cost..tblordercost oc with (nolock) on eii.EiiOpId = oc.OcOpId

left join tblproduct p with (nolock) on EiiPrSku = p.PrSku 
inner join tbljoinProductClass pc WITH(NOLOCK) ON EiiPrSKU = pc.prsku
left join tblclass cl WITH(nolock) on pc.Clid = cl.ClID
inner join tblProdDescXmlSchema sch WITH(NOLOCK) ON pc.clid = sch.PdxClID
inner join tblSchemaTag s WITH(NOLOCK) ON sch.PdxSchemaID = s.StagSchemaID
left join tblProductTag t WITH(NOLOCK) ON p.PrSKU = t.PtagPrSKU and s.StagID = t.PtagStagID
left join vwProductTagAllEnumValues v WITH(NOLOCK) ON t.PtagID = v.PtagID

where cl.Clid in ('1221') 

--and s.StagActive = 1
--and c.PcMasterClass = 1
--and stagID in ('30299', '30324', '218042', '30300') 
and EoiPODate >= '1-1-2016' and EoiPoDate < '1-1-2020'
and EoiOkToSend = '1'
and EoiSTCyID = '2'
group by

EiiPrSku,

--sum(EiiRetailPrice)
EiiHsCode,
--EoiPoNumSend,
cl.ClID