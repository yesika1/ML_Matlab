/*
Script determines the detention days for a SPO

"detention" charge is from an ocean carrier
These charges are assessed to the cargo owner when a container 
is not returned within a set number of days (free days)
So basically it's a charge they'll give us if we have the container
for more time than the allotted "Free Days" we have in our contract.

We want to determine the number of days between "Wharf gated out" 
at the destination port and "Empty return" when we give it back
 to the port after it's emptied at the warehouse.
 So basically when we pick it up and when we give it back


Server: SQLREPORTING01
*/

select
--*
--right('wharfgateout_cw',11), as extractstring
SpoID, SupplierName, wharfgateout_cw as 'Wharf Gate Out'
--, emptycontainerreturn_cw
, emptycontainerreturn_master as 'Empty Cont. Return'
-- ,datediff (hour, wharfgateout_cw, emptycontainerreturn_maste) AS days_diff
, DATEDIFF (hour, wharfgateout_cw, emptycontainerreturn_master)/24 AS days_diff

FROM csn_export_scl.dbo.tblISCDatamart with (nolock)
where SpoID = 'WHS-24819-4625766'