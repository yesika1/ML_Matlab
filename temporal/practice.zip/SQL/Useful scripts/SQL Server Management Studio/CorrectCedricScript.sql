select 
	op.opid AS 'OpID',
	eoi.EoiPONumSend AS 'PO Num',
	isnull(s.suparentsuid, S.suid) [SuID],
	eoi.eoiDateSent AS 'Date Sent',
	eii.eiiRetailPrice AS 'Price', 
	eii.eiiQty AS 'Qty',
	tphs.MFN AS 'Duty Rate', 
	eii.EiiOriginCountryShort AS 'Origin Country', 
	eoiSupplierName AS 'Supplier Name',
	eii.eiiMaName AS 'Manufacturer Name',
	jpt.TryID

from csn_order..tblOrderProduct op with (nolock)
join csn_international..tblEDIOutItemIntl eii with (nolock) on op.opid=eii.EiiOpID
join csn_international..tblEDIOutIntl eoi with (nolock) on EoiID=EiiEoiID

join csn_product..tblproduct p with (nolock) on p.PrSKU=op.OpPrSKU
join csn_product..tblplcountry c with (nolock) on p.PrCyId = c.CyID
left join csn_product..tblsupplier s with (nolock) on op.OpSuID = s.SuID
join csn_product..tblHSCodeCountry hs with (nolock) on p.PrSKU=hs.HsPrSKU
join csn_shiprates..tphs tphs with (nolock) on p.PrHsCodeBase = tphs.HSCodeBase and hs.HsCodeCountry=tphs.HSCountryCode
left join csn_product..tbljoinProductTreaty jpt with (nolock) on p.PrSKU=jpt.PrSku

where hs.HsCyId=2
and eoi.eoiOkToSend=1 
and (eoi.eoiDateSent between '2019-12-01' and '2019-12-31')
and (tryid is null or tryid <> 1)
and isnull(s.suparentsuid, S.suid) not in (21028,2826,7347,20613,1664,6180,83,17301,1748,8430,15784,15231,421,12048,14785,5489,19553,15817,7141,2022,31095,8595,203,308,3215,13552,11377,39237,12430,26281)
and eii.EiiOriginCountryShort in('US', 'CA', 'MX')
ORDER BY EoiDateSent ASC;
