SELECT Top 10 p.PrSKU,s.SuName
FROM CSN_product..tblproduct p with (nolock) 

LEFT JOIN CSN_product..tbljoinproductsupplier ps with(nolock) ON p.PrManuPartNum = ps.ManuProdID

LEFT JOIN CSN_product..tblsupplier s with (nolock) ON ps.SUID = s.SUID;
