select 
p.prsku,
p.PrName,
s.stagID,
    TagTitle = StagTitle
  , TagValue = ISNULL(PtagValue, Value)
from tblProduct p WITH(NOLOCK)
inner join tbljoinProductClass c WITH(NOLOCK) ON p.PrSKU = c.prsku
inner join tblProdDescXmlSchema sch WITH(NOLOCK) ON c.clid = sch.PdxClID
inner join tblSchemaTag s WITH(NOLOCK) ON sch.PdxSchemaID = s.StagSchemaID
left join tblProductTag t WITH(NOLOCK) ON p.PrSKU = t.PtagPrSKU and s.StagID = t.PtagStagID
left join vwProductTagAllEnumValues v WITH(NOLOCK) ON t.PtagID = v.PtagID
where p.PrSKU IN ('DAN1392',
'OHN3140',
'EJH1138',
'NEWA1106',
'NST1627',
'OHN3140',
'OHN3140',
'OHN3140',
'OHN3140',
'FTGX1031',
'OHN3140')
and s.StagActive = 1
and c.PcMasterClass = 1
