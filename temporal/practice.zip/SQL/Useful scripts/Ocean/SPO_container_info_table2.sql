/*
This second query is what has BOL number in it ("LiBOLNumber") and the SPO number in this script is labeled "LiPONumber"
server: SQLREPORTING02
*/


select distinct
a.LiTsID
,a.LiID
,LiDateCreated
,LiDateLoaded
,LiAttempts
,LiStatus
,LiPONumber
,LiContainerNumber
,LiBOLNumber
--,LiErrorType
--,LiErrorList
,LiInvoiceNumber
,IiDescription
,IiDescrCode
,IiUnitPrice
,DestinationWarehouse
,LiTotalCost
from
csn_invoice.dbo.tblLoadInvoice a
join csn_invoice.dbo.tblLoadInvoiceItem b with(nolock) on a.[LiID] = b.[IiLiID]
left join csn_reporting_isc.dbo.tblInboundSPOMilestones with (nolock) on LiPONumber = SpoID
--join csn_invoice.dbo.tblInvoiceWeatherTrackingLog I WITH (NOLOCK) on I.LiID = a.LiID
--INNER JOIN csn_invoice.dbo.tblplInvoiceWeatherAction c WITH (NOLOCK) on c.ActionID = I.ActionID
where
[LiTsID] in ('562','725','999','1150','1152','1151', '1153', '1155', '544','695','790','934','944')
and IiUnitPrice <> '0'
--and LiDateLoaded between '2020-03-23' and '2020-04-05'

and LiPONumber = 'WHS-3026-5754265'

