USE [csn_financial_report]
GO

/****** Object:  StoredProcedure [dbo].[spArPaymentsReportProcessor]    Script Date: 03/07/2018 1:11:28 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




/* 
exec spArPaymentsReportProcessor 2000,-.05
This processor takes PyIds FROM tblArReportingQueue AND processes them for the AR Payments Report
It is called through jenkins. 


*/

ALTER PROCEDURE [dbo].[spArPaymentsReportProcessor]
	(
		  @BatchSize INT
		, @ProcessDelay INT = -5 --In minutes; should be NEGATIVE, default to 60 minute delay
	)

AS

BEGIN

	SET NOCOUNT ON

	BEGIN TRY

	DECLARE @BatchID INT
	DECLARE @RecordsToProcess INT = -1
	

	CREATE TABlE #PyIDsToProcess
		(
			ArrqID bigint PRIMARY KEY, 
			PyIDProcessingRank int,
			PyId bigint,
			PyOrID bigint,
			PyWasDeleted bit
		)

	CREATE TABLE #PyIDsInsertedUpdated
		(
			ArrqID bigint,
			PyID bigint
		)


	CREATE TABLE #PyIDsDeleted
		(
			ArrqID bigint,
			PyID bigint
		)


	CREATE TABLE #ValidInsertsUpdates 
		( 
			ArrqID bigint,
			PyId bigint,
			PyOrId bigint,
			MtText nvarchar(255),
			MtId int,
			PaymentStatus nvarchar(255),
			PyPaidDate datetime,
			PyTotal money,
			PyIsChargeback bit,
			PyBtId bigint,
			PyOther nvarchar(255),
			SoName nvarchar(255),
			SoId int,
			CrName nvarchar(255),
			CrID int,
			CorrectedCrID int,
			OrCuyId nvarchar(3),
			StyId int,
			StyName nvarchar(64),
			PeriodID int,
			PeriodName Nvarchar(10)
		)

	CREATE TABLE #NotValidInsertsUpdates
		(
			PyID bigint
		)

	CREATE TABLE #Deletes 
		(
			  ArrqID bigint
			, ArpdId bigint
			, PyId bigint
			, FinalDelete bit
		)

	INSERT INTO #PyIDsToProcess (ArrqID, PyIDProcessingRank, PyID, PyWasDeleted, PyOrId)
		SELECT TOP (@BatchSize) 
			ArrqID
			, ROW_NUMBER() OVER(Partition by q.PyId ORDER BY q.arrqPyWasDeleted DESC) --We only want distinct PyIDs. Deleted takes precedence over inserts/updates
			, q.PyID
			, arrqPyWasDeleted
			, p.PyOrId
		FROM csn_financial_report.dbo.tblARReportingUpdateQueue q WITH (NOLOCK)
		LEFT JOIN csn_order.dbo.tblOrderPayment p with (nolock) on q.pyid=p.pyid
		WHERE NOT EXISTS
			(SELECT TOP 1 1 FROM csn_financial_report.dbo.tblArReportingUpdateQueue_Status qs WITH (NOLOCK) WHERE q.ArrqID = qs.ArrqID AND (IsSuccessful=1 OR IsProcessing=1))
		AND NOT EXISTS 
			(SELECT 1 FROM csn_financial_report.dbo.tblArReportingUpdateQueue_Status ER WITH (NOLOCK) WHERE ER.ArrqID=q.ArrqId AND HasError=1 group by ArrqID having count(*)>4) --Dont re-process if error count > 5 
		AND q.ArrqCreateDate < DATEADD(MINUTE,@ProcessDelay,GETDATE()) --Buffer to ensure we're pulling PyIDs that have been committed FROM a transaction
		-- ORDER BY ArrqID ASC (removed the order by)
	
		CREATE NONCLUSTERED INDEX IX_PyId ON #PyIDsToProcess (PyID) -- removed the desc from NonClustered Index
	
		SELECT @RecordsToProcess = COUNT(*) FROM #PyIDsToProcess

	IF @RecordsToProcess > 0
		
			BEGIN

			--Create new batch
			INSERT INTO csn_financial_report.dbo.tblArPaymentsBatch (ArpDateProcessed, ArpBatchSize, ArpError)
				SELECT GETDATE(), @RecordsToProcess, NULL

			SET @BatchID = SCOPE_IDENTITY(); 

			--Mark the queue'd record as processing
				INSERT INTO csn_financial_report.dbo.tblArReportingUpdateQueue_Status (ArrqID, ArrqBatchID, ArrqProcessedDate, HasError, IsProcessing, IsSuccessful)
					SELECT
						ArrqID, @BatchID, GETDATE(), 0, 1, NULL
					FROM #PyIdsToProcess

			/* INSERTS */ 
				INSERT INTO #PyIDsInsertedUpdated (ArrqID, PyID)
					SELECT 
						ArrqId
						, PyID
					FROM #PyIDsToProcess ptp
					WHERE PyWasDeleted = 0
					and PyIDProcessingRank=1

				/*Grab universal framework. The triggers should eliminate anything we dont want. However, we still want to check to make 
				 sure the Payment is in the correct state */
				 INSERT INTO #ValidInsertsUpdates (ArrqID, PyId, PyOrId, MtText, MtID, PaymentStatus, PyPaidDate, PyTotal, PyIsChargeback, PyBtId, PyOther, SoName, SoID, CrName, CrId, OrCuyId, StyId, StyName, PeriodID, PeriodName)
					SELECT
						ArrqID
						, p.PyId
						, PyOrId
						, CASE WHEN PyMtID <> 1 THEN MtText ELSE CRNAME END
						, PyMtId
						, PyPmID
						, PyPaIdDate
						, PyTotal
						, ISNULL(PyIsChargeback,0) 
						, PyBtId
						, PyOther
						, SoName
						, SoId
						, CrName
						, PyCrId
						, OrCuyID
						, StyID
						, StyName
						, ArPeriodID
						, ArPeriodName
					FROM #PyIdsInsertedUpdated a
					INNER JOIN csn_order.dbo.tblOrderPayment p with (nolock) on p.pyid=a.pyid
					INNER JOIN csn_order.dbo.tblOrder o with (nolock) on o.OrID=p.pyorid
					INNER JOIN csn_order.dbo.tblStore s with (nolock) on s.soid=o.orsoid
					INNER JOIN csn_order.dbo.tblSubentity se with (nolock) on se.styid=sostyid
					INNER JOIN csn_order.dbo.tblplPaymentMethod mt with (nolock) on p.pymtid=mt.mtid
					INNER JOIN csn_order.dbo.tblplPaymentStatus pm with (nolock) on p.pypmid=pm.pmiD
					INNER JOIN csn_financial_report.dbo.tblArReportingPeriod arp with (nolock) on arp.ArPeriodMonth=month(PyPaidDate)
					LEFT JOIN csn_order.dbo.tblplCreditCard cr with (nolock) on cr.crid=pycrid
					WHERE PyPaidDate IS NOT NULL
					AND PyPmId=2
					AND arp.ArPeriodYear=year(PyPaIddate)
          OPTION (USE HINT ( 'FORCE_DEFAULT_CARDINALITY_ESTIMATION')) -- C4 optimization added 11/9/2017 by jtsmith


			--Payments are not settled
				INSERT INTO #NotValidInsertsUpdates (PyID)
					Select 
						ptp.PyId 
					from #PyIDsInsertedUpdated ptp
					inner join csn_order.dbo.tblOrderPayment py with (nolock) on ptp.pyid=py.pyid
					where (PyPaidDate IS NULL OR PyPmID <> 2)

			--Payments that are no longer settled	
				INSERT INTO #Deletes (ArpdID, PyID, FinalDelete)
						SELECT 
							ArpdID
							, PyID
							, 0 
						FROM csn_financial_report.dbo.tblARPaymentsDetailReport a
						WHERE EXISTS (SELECT 1 FROM #NotValidInsertsUpdates b where a.pyid=b.pyid) 
						AND NOT EXISTS (SELECT 1 FROM csn_financial_report.dbo.tblARPaymentsDetail_Deleted c with (nolock) where c.arpdid=a.arpdid) --already deleted

			--Settled payments where a column changed 
					INSERT INTO #Deletes (ArpdID, PyID, FinalDelete)
						SELECT 
							ArpdID
							, PyID
							, 0 
						FROM csn_financial_report.dbo.tblARPaymentsDetailReport a
						WHERE EXISTS (SELECT 1 FROM #ValidInsertsUpdates b where a.pyid=b.pyid) 
						AND NOT EXISTS (SELECT 1 FROM csn_financial_report.dbo.tblARPaymentsDetail_Deleted c with (nolock) where c.arpdid=a.arpdid) --already deleted

 
			/* DELETES */
				INSERT INTO #PyIdsDeleted (PyID)
					SELECT
						PyID
					FROM #PyIDstoProcess
					WHERE PywasDeleted=1
					and PyIDProcessingRank=1

			--Final Deletes. Deleted FROM tblOrderPayment
				INSERT INTO #DELETES  (ArpdId, PyId, FinalDelete)
					SELECT
						 ArpdID
						, pd.PyID
						, 1
					FROM #PyIdsDeleted pd
					INNER JOIN csn_financial_report.dbo.tblArPaymentsDetailReport ar with (nolock) on ar.pyid=pd.pyid
					AND NOT EXISTS (SELECT 1 from csn_financial_report.dbo.tblArPaymentsDetail_deleted d WITH (NOLOCK) WHERE d.arpdid=ar.arpdid) --record isnt in delete table already

			BEGIN TRANSACTION

				-- Inserts 
					INSERT INTO csn_financial_report.dbo.tblARPaymentsDetailReport
					(PyId, OrID, CashReceipt, PyMtID, PaidDate, Payment, PyIsChargeback, BankingTransactionNum, PaymentNote, Store, SoId, CrId, CreditCardType, Currency, Subentity, SubentityName, ProcessCount, periodID, PeriodName)
						SELECT distinct
							PyId, PyOrId, MtText, MtId, PyPaIdDate, PyTotal, PyIsChargeback, PyBtId, PyOther, SoName, SoID, CrId, CrName ,  OrCuyID , StyID, StyName, 1, PeriodID, PeriodName
						FROM #ValidInsertsUpdates

				--Deletes
					INSERT INTO csn_financial_report.dbo.tblArPaymentsDetail_Deleted (arpdId, ArpdFinalDelete, ArpdDateDeleted)
						SELECT Distinct
							 ArpdId, FinalDelete, getdate() 
						FROM #Deletes
				
				--Update status table to note that these records are no longer in processing AND are successful.
					UPDATE py
					SET IsProcessing = 0
						, IsSuccessful = 1
						, HasError = 0
					FROM csn_financial_report.dbo.tblARReportingUpdateQueue_Status py
					WHERE EXISTS (SELECT 1 FROM #PyIDsToProcess pp WHERE pp.ArrqID= py.ArrqID)

			COMMIT TRANSACTION
				
				SELECT 'Batch ' + CAST(@BatchID AS VARCHAR(15)) + ' successful; '
					+ CAST(@RecordsToProcess AS VARCHAR(15)) + ' records processed' AS [Result]

			END

		ELSE

			BEGIN

				SELECT 'There are no records to process on the queue; no action taken.' AS [Result]

			END

	END TRY

	BEGIN CATCH

		DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE()
		DECLARE @ErrorState INT = ERROR_STATE()
		DECLARE @ErrorLine INT = ERROR_LINE()
		DECLARE @ErrorSeverity INT= ERROR_SEVERITY()
	
		IF @@TRANCOUNT > 0
			BEGIN
				ROLLBACK TRANSACTION
			END

		UPDATE csn_financial_report.dbo.tblArPaymentsBatch
		SET ArpError = @ErrorMessage + ' | ' + CAST(@ErrorState AS NVARCHAR) + ' | ' + CAST(@ErrorLine AS NVARCHAR)
		WHERE arpBatchID = @BatchID;
	
		UPDATE csn_financial_report.dbo.tblArReportingUpdateQueue_Status
		SET HasError = 1
			,IsProcessing = 0
		WHERE ArrqBatchID = @BatchID


		RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
	
	END CATCH
END

;
GO