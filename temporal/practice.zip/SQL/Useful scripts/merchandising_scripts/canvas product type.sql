/*
----------------------------------------------------------------------------------
CANVAS PRODUCT TYPE (INCLUDED)
----------------------------------------------------------------------------------
Use this script to retrive a list of product SKU that can contain a specific stag type given the product classID (CLID),  Stag Title and staglevel (ex when contain word canvas)
Ex: given Class: CLID 1318 Wall Art - Wall Art - GLOBAL
Schema: StagID 157233 Primary Art Material
Stag value, Level: StevID 221217 Canvas

not useful here but shows the level type--left join csn_product..tblSchemaTagEnumValue stev (NOLOCK) ON stev.StevStagID = s.StagID --added by yesika

-- Input: Product classID(ClID)
-- Output: 
-- Server: sqlBoadhoc

*/


select top 10
c.ClID, p.PrSKU,PrName, StagTitle, StagID,  isnull(v.value, PtagValue) as Value,
c.ClName
--stev.StevID, stev.StevValue
--distinct StagTitle, StagCustomerDefinition, c.ClID
--EoiPoNumSend, EoIPoDate,, EiiOpID, p.prsku

from
csn_product..tblproduct p with (nolock) 
left join csn_product..tbljoinproductclass pc with (nolock) on p.prsku=pc.prsku
left join csn_product..tblclass c WITH(nolock) on pc.Clid = c.ClID
inner join csn_product..tblProdDescXmlSchema sch WITH(NOLOCK) ON pc.clid = sch.PdxClID
inner join csn_product..tblSchemaTag s WITH(NOLOCK) ON sch.PdxSchemaID = s.
StagSchemaID
left join csn_product..tblProductTag t WITH(NOLOCK) ON p.PrSKU = t.PtagPrSKU and s.StagID = t.PtagStagID
left join csn_product..vwProductTagAllEnumValues v WITH(NOLOCK) ON t.PtagID = v.PtagID

--from csn_order..tblOrderProduct a with (nolock)
--join csn_order..tblsupplier b with (nolock) on a.OpSuID=b.SuID

where
--StagID = 157233
--and (isnull(v.value, PtagValue)) IS not  NULL

--p.PrSKU = 'OVR2672'
--ANd StagID = 226729

c.ClID = 1318


/*
where
StagTitle in ('Primary Art material details')
and (isnull(v.value, PtagValue)) IS NULL
OR
StagTitle = 'Primary Art Material'
--and p.prsku ='AAD10054'
*/

--and ptagstagid in ('3217', '151285')
--and StagTitle in ('Commercial Warranty', 'Number of Jets', 'Commercial OR Residential Certifications')

--group by p.PrSKU, PrName, StagTitle, StagID, PtagStagID, c.ClID, isnull(value, PtagStagID)


--where eoi.EoiPoDate > '2016-01-01'
--a.OpReCyID = 2 and b.SuStyID=1 and OpPrPrice>1

 

