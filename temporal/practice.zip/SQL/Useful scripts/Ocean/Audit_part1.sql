/*
Script 1: Sample & SPO info

- Given a date in where clause:
This script pulls SPOs that had containers returned empty to the port 
between a given number of months in a year.
Set the year and months in the where clause: EmptyContainerReturn_Master
Used to get a sample

- Given a spo in where clause:
This script pull an SPO and accompanying shipment information	

- IF OnTime delivery = yes, then there are not additional shipping charges
like Accessorials per diem, demurrage, 	etc.

Database:SQLREPORTING01
Updated:	4/22/20	4:35 PM	
*/
-------------------------------------------------------------------------------

SELECT
distinct
SpoID as 'SPO',
ContainerNumber as 'Container No.',
LiBOLNumber as 'BOL No.',

case 
when OnTimeDeliveryFlag = 1 then 'Yes'
when OnTimeDeliveryFlag = 0 then 'No'
else 'unknown'
end as 'OnTime Delivery',
'' as '-',
OriginPortCode as 'Port of Origin',
DestinationPortCode as 'Port of Destination',
SpoInboundServiceLevelName as 'Service Level',

case 
when SupplierName like '%Veradek%' then 'EXW supplier'
when SupplierName like '%ACG Green%' then 'EXW supplier'
else 'FOB'
end as 'Incoterm',
CAST(gateinoriginport AS date) as 'Wharf Gate In',
--CAST(wharfgateout_cw AS date) as 'Wharf Gate Out',
CAST(emptycontainerreturn_master AS date) as 'Empty Container Returned',
'' as 'date_Check',
'' as 'Data Integrity',
OceanCarrierName as 'Ocean Carrier',
DrayCarrierName as 'Dray Carrier',

'' as '-',
OceanCarrierName as 'Ocean Carrier',
OriginPortCode as 'Origin Port',	
case when Originportcode = 'CNFZG' then 'China'	
when Originportcode = 'CNFZH' then 'China'	
when Originportcode = 'CNYTN' then 'China'	
when Originportcode = 'CNSHG' then 'China'	
when Originportcode = 'CNTAZ' then 'China'	
when Originportcode = 'CNNBG' then 'China'	
when Originportcode = 'CNTXG' then 'China'	
when Originportcode = 'CNTYN' then 'China'	
when Originportcode = 'CNWHG' then 'China'	
when Originportcode = 'CNXAO' then 'China'	
when Originportcode = 'CNXMG' then 'China'	
when Originportcode = 'CNZPU' then 'China'	
when Originportcode = 'CNZSN' then 'China'	
when Originportcode = 'IDJKT' then 'Indonesia'	
when Originportcode = 'IDSRG' then 'Indonesia'	
when Originportcode = 'IDSUB' then 'Indonesia'	
when Originportcode = 'INMUN' then 'India'	
when Originportcode = 'INNSA' then 'India'	
when Originportcode = 'MYPEN' then 'Malaysia'	
when Originportcode = 'MYPGU' then 'Malaysia'	
when Originportcode = 'MYPKG' then 'Malaysia'	
when Originportcode = 'MYTPP' then 'Malaysia'	
when Originportcode = 'THLCH' then 'Thailand'	
when Originportcode = 'TWKHH' then 'Taiwan'	
when Originportcode = 'TWTXG' then 'Taiwan'	
when Originportcode = 'VNDAD' then 'Vietnam'	
when Originportcode = 'VNIPH' then 'Vietnam'	
when Originportcode = 'VNDNA' then 'Vietnam'	
when Originportcode = 'VNSGN' then 'Vietnam'	
when Originportcode = 'VNUIH' then 'Vietnam'	
else 'Other'	
end as 'Origin Country',	
DestinationPortCode as 'Desination Port',	
case when DestinationPortCode = 'USNYC' then 'US (EC)'	
when DestinationPortCode = 'USSAV' then 'US (EC)'	
when DestinationPortCode = 'USOAK' then 'US (WC)'	
when DestinationPortCode = 'USORF' then 'US (EC)'	
when DestinationPortCode = 'USLGB' then 'US (WC)'	
when DestinationPortCode = 'USLAX' then 'US (WC)'	
when DestinationPortCode = 'USJAX' then 'US (EC)'	
when DestinationPortCode = 'USEWR' then 'US (EC)'	
when DestinationPortCode = 'USDAL' then 'US (EC/WC)'	
when DestinationPortCode = 'USCVG' then 'US (EC)'	
when DestinationPortCode = 'GBSOU' then 'UK'	
when DestinationPortCode = 'DEHAM' then 'Germany'	
when DestinationPortCode = 'DEBRV' then 'Germany'	
when DestinationPortCode = 'CATOR' then 'Canada'	
else 'Other'	
end as 'Destination Country',	
--DestinationWarehouse as 'Dest. Warehouse',
CAST(gateinoriginport AS date) as 'Wharf Gate In'
--, wharfgateout_cw
,CAST(wharfgateout_cw AS date) as 'Wharf Gate Out'
,EmptyContainerReturn_Master
,datediff (day, wharfgateout_cw, EmptyContainerReturn_Master) AS days_diff 
, DATEDIFF (hour, wharfgateout_cw, emptycontainerreturn_master)/24 AS days_diff_hrs
,datediff (day, wharfgateout_cw, EmptyContainerReturn_Master)-10 AS days_perDiem 


, '' as '-'
,DestinationWarehouse as 'Dest. Warehouse'	
,DrayCarrierName as 'Dray Carrier'
, '' as '-'
,Suppliername as 'Supplier Name'	

FROM csn_export_scl.dbo.tblISCDatamart with (nolock)
left join csn_invoice.dbo.tblLoadInvoice a with(nolock) on LiPONumber = SpoID																									
left join csn_invoice.dbo.tblLoadInvoiceItem b with(nolock) on a.[LiID] = b.[IiLiID]																									

WHERE																									
[LiTsID] in ('562','725','999','1150','1152','1151', '1153', '1155', '544','695','790','934','944')																									
and IiUnitPrice <> '0'																									
and spoiscancelled = 0 and																									
SpoID = 'WHS-3026-6013211'																									
--SpoID = 'WHS-1093-5911538'



