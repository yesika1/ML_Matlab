/*
Use this script to review the EDI information that was sent to the broker.
The first table shows all of the information that was generated. 

The second table is only the information that was sent to Farrow.
Rows where EoiOkToSend=1 indicates it was sent to the broker.
Rows where EbiDateSent is populated indicates it was actually sent and there weren't any issues.
There are occasions where EoiOkToSend=1 has multiple rows, but only one of them was sent (indicated by EbiDateSent). 
On the other hand, some successful EDI sends don't have a date in EbiDateSent.

Server:
FYI this has to be run on the server sqlBoadhoc

*/

declare @OpID as bigint
set @OpID = 3613356775; --Insert the OpID # here

select *
from csn_international..tblEDIOutItemIntl Eii with (nolock)
join csn_international..tblEDIOutIntl Eoi with (nolock) on Eii.EiiEoiID = Eoi.EoiID 
where EiiOpId=@OpID

select Ebi.* -- Ebi.*
from csn_international..tblEDIOutItemIntl Eii with (nolock)
join csn_international..tblEDIOutIntl Eoi with (nolock) on Eii.EiiEoiID = Eoi.EoiID
join csn_international..tblEDIOutBolIntl Ebi with (nolock) on Eoi.EoiEbiID = Ebi.EbiID
where 
EoiOkToSend = '1' --Add "and EbiDateSent is not null" if you want just the ones sent to the broker
and EiiOpID = @OpID


