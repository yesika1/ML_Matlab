/*
Script 3: Buy-Side Charges

This script pulls IPS charge information for a given SPO.								
Notes: Evergreen charges go through CargoSprint, not IPS. 
For Evergreen charges, use "CARGOSPRINT TRACKER" in Google Drive.
Other ocean carriers may not have charges appearing in IPS prior to mid-March.								

Database:	SQLREPORTING02				
Updated:	4/24/20	6:08 PM	
*/
-------------------------------------------------------------------------------								
								
select distinct								
a.LiTsID								
,LiPONumber as 'SPO'								
,LiBOLNumber as 'BOL No.'								
--,LiContainerNumber as 'Container No.'								
,OceanCarrier as 'Ocean Carrier'								
,DrayTsName as 'Dray Carrier'								
,LiDateCreated as 'Invoice Entry Created'								
--,liinvoicedate as 'Date Invoiced'								
--,LiDateLoaded as 'Date Loaded'								
,LiStatus as 'Status'	
, LiInvoiceNumber 	-- added yesika

,case
when IiDescription like '%Base%' and IiDescrCode = 'OCEAN' then 'Ocean Base Rate'																								
when IiDescription like '%fuel%' and IiDescrCode = 'BUNKER' then 'Ocean Bunker'	
when IiDescription like '%Base%' and IiDescrCode = 'DRAY' then 'Dray Base Rate'	
when IiDescription like '%split Chassis%' then 'Dray Split Chasis'	
when IiDescription like '%Chassis%' and IiDescrCode = 'CHASSIS' then 'Dray Chassis Rental'	
when IiDescription like '%fuel%' and IiDescrCode = 'DFSC' then 'Dray Fuel'		
when IiDescription like '%fuel%' then 'Dray Fuel'		
when IiDescription like '%Chassis%' then 'Dray Chassis'								
when IiDescription like '%Bunker%' then 'Ocean Bunker'
when IiDescription like '%Marinefuel%' then 'Ocean Bunker'	
when IiDescription like '%Marine fuel%' then 'Ocean Bunker'	
when IiDescription like '%Port Congestion%' then 'Congestion'								
when IiDescription like 'Drayage Charge%' then 'Dray Base Rate'								
when IiDescription like  '%Container Drayage%' then 'Dray Base Rate'								
when IiDescription like  '%Base%'  then 'Dray Base Rate'																									
when IiDescription like '%Document%' then 'DDOC'								
when IiDescription like '%Peak%' then 'PSS'	
when IiDescription like '%Pier%' then 'Pier Pass'								
when IiDescription like '%Security%' then 'Security Fee'								
when IiDescription like '%AMS%' then 'AMS Filing Fee'								
when IiDescription like '%Exam%' then 'Exam'				
else 'Other'								
end as 'Charge'	

,IiDescription as 'Charge Description'								
,IiUnitPrice as 'Unit Price'								
,IiRatedCost								
--,LiInvoiceNumber as 'Invoice No.'								
,IiDescrCode as 'Desc. Code'								
,DestinationWarehouse as 'Destination WH'								
,LiTotalCost as 'Total Vendor Cost'				




				
from								
csn_invoice.dbo.tblLoadInvoice a with(nolock)							
join csn_invoice.dbo.tblLoadInvoiceItem b with(nolock) on a.[LiID] = b.[IiLiID]								
left join csn_reporting_isc.dbo.tblInboundSPOMilestones with (nolock) on LiPONumber = SpoID								
--join csn_invoice.dbo.tblInvoiceWeatherTrackingLog I WITH (NOLOCK) on I.LiID = a.LiID								
--INNER JOIN csn_invoice.dbo.tblplInvoiceWeatherAction c WITH (NOLOCK) on c.ActionID = I.ActionID								
where								
[LiTsID] in ('562','725','999','1150','1152','1151', '1153', '1155', '544','695','790','934','944')								
and IiUnitPrice <> '0'								
and LiPONumber = 'WHS-381-4643044'	
ORDER BY Listatus, LiDateCreated ASC		


--WHS-39315-5405767
--WHS-3026-5754265
			