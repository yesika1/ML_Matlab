/*
script that pull all charges that an SPO receives 
(ocean and dray - including detention charges)

server:SQLREPORTING02
*/


select distinct
a.LiTsID
,LiPONumber as 'SPO'
,LiBOLNumber as 'BOL No.'
--,LiContainerNumber as 'Container No.'
,OceanCarrier as 'Ocean Carrier'
,DrayTsName as 'Dray Carrier'
,LiDateCreated as 'Invoice Entry Created'
,liinvoicedate as 'Date Invoiced'
,LiDateLoaded as 'Date Loaded'
,LiStatus as 'Status'
,IiDescription as 'Charge Description'
,IiUnitPrice as 'Unit Price'
,IiRatedCost
--,LiInvoiceNumber as 'Invoice No.'
,IiDescrCode as 'Desc. Code'
,DestinationWarehouse as 'Destination WH'
,LiTotalCost as 'Total Vendor Cost'
from
csn_invoice.dbo.tblLoadInvoice a
join csn_invoice.dbo.tblLoadInvoiceItem b with(nolock) on a.[LiID] = b.[IiLiID]
left join csn_reporting_isc.dbo.tblInboundSPOMilestones with (nolock) on LiPONumber = SpoID
--join csn_invoice.dbo.tblInvoiceWeatherTrackingLog I WITH (NOLOCK) on I.LiID = a.LiID
--INNER JOIN csn_invoice.dbo.tblplInvoiceWeatherAction c WITH (NOLOCK) on c.ActionID = I.ActionID
where
[LiTsID] in ('562','725','999','1150','1152','1151', '1153', '1155', '544','695','790','934','944') and
IiUnitPrice <> '0'
and
--LiBOLNumber = '43854466'
LiPONumber = 'WHS-24819-4625766'
ORDER BY Listatus, LiDateCreated ASC
--only look at LiStatus = C