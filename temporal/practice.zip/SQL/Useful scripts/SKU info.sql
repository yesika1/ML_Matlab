/*
Use this script to review customs-related information for a given product.

prSKU = Product SKU
PrName = Product Name
CountryofOrigin = Country of Origin
HSCyID = The country code of that HS Code (2 equals Canada)
Tariff = HS Code
MFNDutyRate = Duty rate for US to Canada imports
TryID = Flag if a product qualifies for Nafta. 1=Nafta eligible; Null=Not Nafta eligible

*/

select p.prSKU, p.PrName,p.PrStatus, s.PrStatusName, s.PrStatusActive, c.CyLongName as 'CountryOfOrigin', hs.HsCyId, tphs.TARIFF, tphs.MFN as 'MFNDutyRate', jpt.TryID
from csn_product..tblproduct p with (nolock)
join csn_product..tblplcountry c with (nolock) on p.PrCyId = c.CyID
join csn_product..tblHSCodeCountry hs with (nolock) on p.PrSKU=hs.HsPrSKU
join csn_shiprates..tphs tphs with (nolock) on p.PrHsCodeBase = tphs.HSCodeBase and hs.HsCodeCountry=tphs.HSCountryCode
left join csn_product..tbljoinProductTreaty jpt with (nolock) on p.PrSKU=jpt.PrSku
left join csn_product..tblplProductStatus s  with (nolock) on p.PrStatus = s.PrStatus
where hs.HsCyId=2
and p.prSKU in ('LBA2927',
'EPCU1000',
'JANP1022',
'ALCT7492',
'BLMK9448',
'WRLO2230',
'ATGR8495
') --Insert SKU(s) here




