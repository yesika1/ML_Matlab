Select 
--distinct ca.*
distinct
ca.OpID,
f.PONumber as 'PONumber',   
f.SalesQty,  
PortNumber as 'Port of Clearance',
TransActionNumber as 'Transaction Number',
EntryType as 'Entry Type',
AccountingDate as 'Accounting Date', 
ca.B3SubHeader as 'Subheader',
B3Line as 'Line Number',
TariffTreatment as 'Tariff Treatment',
PrName as 'Description',
ca.HScode as 'Classification Number',
F_Duty as 'Duty Rate',
F_VFCC as 'VFCC',
F_VFDAMT as ' VFD',
F_DutyAMT as 'Customs Duties', 
GSTAMT as 'GST'

from csn_junk.dbo.tblCanadaAudit20172018 ca with (nolock) 
join csn_junk.dbo.tblFarrow f with (nolock) on ca.OpID = f.EiiOpID
join csn_international..tblEDIOutItemIntl eii with (nolock)  on f.EiiOpID = eii.EiiOpID
where 
eii.EiiPrSku in ('OHN3140', 'FTGX1031')



