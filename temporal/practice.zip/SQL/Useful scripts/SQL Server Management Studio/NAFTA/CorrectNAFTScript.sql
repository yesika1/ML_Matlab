drop table if exists #TEST

select
	p.PrSKU,
	p.PrName,
	s.SuName,
	o.OpShipDate,
	o.OpReCyId,
	s.SuStyID,
	--(eii.EiiRetailPrice*tphs.MFN) AS EstimateDuties
	eii.EiiRetailPrice,
	o.OpQty,
	tphs.MFN as 'MFNDutyRate',
	jpt.TryID

--INTO #TEST
from csn_order.dbo.tblOrderProduct o with(nolock)
join csn_order..tblproduct p with(nolock) on o.OpPrSKU = p.PrSKU
join csn_order..tblSupplier s with(nolock) on o.OpSuID = s.SuID
--join csn_international..tblEDIOutItemIntl eii with (nolock) on o.OpID = eii.EiiOpID 
CROSS APPLY(SELECT TOP 1 EiiRetailPrice FROM csn_international..tblEDIOutItemIntl eii with (nolock) WHERE o.OpID = eii.EiiOpID AND eii.EiiShipCarrier IS NOT NULL) eii
join csn_product..tblHSCodeCountry hs with (nolock) on p.PrSKU=hs.HsPrSKU
join csn_shiprates..tphs tphs with (nolock) on p.PrHsCodeBase = tphs.HSCodeBase and hs.HsCodeCountry=tphs.HSCountryCode
CROSS APPLY(SELECT TOP 1  TryID FROM csn_product..tbljoinProductTreaty jpt with (nolock) WHERE o.OpPrSKU = jpt.PrSku) jpt
where (o.OpShipDate BETWEEN '2019-09-01' AND '2019-09-30')
and o.OpReCyID = '2'
and s.SuStyID = '1'
ORDER BY o.OpShipDate ASC;

--SELECT *
--FROM #TEST

--SELECT TOP 50 * FROm csn_shiprates..tphs tphs with (nolock);