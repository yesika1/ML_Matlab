/*
Script 5: Dray Accesorials

This script pulls accessorials approved by the relevant Dray Planner 
for a given container number		
Database:	SQLREPORTING01	
Notes: Only Dray accessorials requiring approval by the Dray Planner are: 
Bobtail, Pre-Pull...	
AccName options are only: Bobtail, Chassis split, and prepull

Add the container number in the where clause under PodTagValue 

Database:	SQLREPORTING02				
Updated:	4/24/20	6:08 PM		
-------------------------------------------------------------------------------		
*/		

select pt.PodTagValue,		
drayleg.draylegID as 'drayleg',		
pla.AccName,		
coa.CoaIsApproved,		
coa.CoaIsActive,		
coa.CoaInsertTime,		
coa.CoaUpdateTime		
from csn_shipment..tblCarrierOrderAccessorial coa  with(nolock)		
left join csn_shipment..tblplAccessorial pla with(nolock) on pla.AccID = coa.CoaAccID		
left join csn_shipment..tblCarrierOrder co with(nolock) on coa.CoaCoID = co.coid		
left join csn_stock..tblpodtag pt with(nolock) on pt.PodTagPodID = co.CoPodID		
outer apply		
(select CASE		
WHEN		
co.CoTypeID = 2 THEN  'Dray Delivery'		
WHEN co.cotypeid = 3 THEN 'Dray Return' else 'Leg unspecified'		
END as DrayLegID)		
Drayleg		
where		
--CoaInsertTime between '2020-02-01' AND '2020-02-28'	
--PodTagValue = 'PONU8010335'		-- Container number found in Script 2
--order by CoaUpdateTime desc		

PodTagValue in ('BMOU6668030',
'GLDU7291233',
'MEDU7504069',
'TCLU4608260',
'MEDU8450985'
)