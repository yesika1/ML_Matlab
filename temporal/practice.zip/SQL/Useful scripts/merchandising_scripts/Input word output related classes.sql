/*
----------------------------------------------------------------------------------
INPUT WORD OUTPUT RELATED CLASSES
----------------------------------------------------------------------------------
Use this script to retrive the Product Class given a word.

-- Input: string describing the class to be found
-- Output: Table with the class (CLID), class name (CLName) and other attributes from the product class table
-- Server: sqlBoadhoc

*/

----------------------------------------------------------------------------------
-- USER INPUT: word
----------------------------------------------------------------------------------
declare @word as varchar(50)
set @word =  '%wall art%'
; --Insert word here

----------------------------------------------------------------------------------
-- MAIN QUERY
----------------------------------------------------------------------------------

select 
--*
ClID, ClName, ClInternalRef, ClMarketingInternalRef, ClClgID, ClDateUpdated

from csn_product..tblClass (nolock)

where ClInternalRef like @word AND
ClInternalRef not like '%DO NOT USE%' AND 
ClInternalRef not like '%RESTRICTED%'
-- where ClInternalRef like '%wall art%'

;
/*
where 
--ClInternalRef not like '%DO NOT USE%'
ClInternalRef like '%wall accent%'
--and ClID='63'
*/