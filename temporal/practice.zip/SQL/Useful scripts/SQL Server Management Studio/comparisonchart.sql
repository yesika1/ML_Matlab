
select top 1*
from csn_order..tblproduct p with(nolock);

select top 1*
from csn_order.dbo.tblOrderProduct o with(nolock); -- poid+shipdate

select top 1*
from csn_order.dbo.tblOrderProductDetail od with(nolock);

select top 1*
from csn_order..tblSupplier s with(nolock);

select top 1*
from csn_product..tblJoinProductSupplier ps with(nolock);

select top 1*
from csn_international..tblEDIOutIntl eoi with (nolock);

select top 1*
from csn_international..tblEDIOutItemIntl eii with (nolock);
