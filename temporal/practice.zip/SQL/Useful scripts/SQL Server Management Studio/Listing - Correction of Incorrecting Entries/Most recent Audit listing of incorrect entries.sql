select
	eii.EiiPrSKU AS 'SKU',
	eoi.EoiPONum AS 'PO',
	eii.EiiName 'Product Name',
	eii.EiiOpID AS 'OpID',
	eii.EiiQty AS 'Qty',
	eii.EiiRetailPrice AS 'VFD',
	eii.EiiHsCode  AS 'HS Code',
	eoi.EoiDateSent AS 'Date Sent'

from csn_international..tblEDIOutItemIntl eii with(nolock)
join csn_international..tblEDIOutIntl eoi with(nolock) on eii.EiiEoiID = eoi.EoiID

where (eoi.EoiDateSent BETWEEN '2017-01-01' and '2019-09-30')
and EoiOkToSend = '1'
and EoiSTCyID = '2'
and EoiExporterCountry = 'US'
and EiiPrSKU in ('OHN3140','EJH1138','NEWA1106', 'FTGX1031')
ORDER BY EoiDateSent ASC; 

