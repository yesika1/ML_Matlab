
select 
EiiOpID AS 'OpID',
EiiQty AS 'QTY',
EiiRetailPrice AS 'Retail Price',
EiiPrSKU AS 'SKU',
EiiName AS 'Product Name',
EiiHsCode AS 'HS Code',
EiiOriginCountry AS 'Origin Ctry',
EoiOkToSend AS 'Crossed Border Successfully',
EoiDateSent AS 'Date Sent',
EoiPONumSend AS 'PO #',
EoiSupplierName AS 'Supplier Name'


from csn_international..tblEDIOutItemIntl eii with(nolock)
join csn_international..tblEDIOutIntl eoi with(nolock) on eoi.EoiID = eii.EiiEoiID
where EiiOpID in
('2599307231',
'2572001845',
'2685426985',
'2692561969',
'8144387000',
'8144356330',
'2749474661',
'2819111479',
'2819111169',
'2859315185')
and EoiOkToSend = 1
ORDER BY EoiDateSent ASC;

