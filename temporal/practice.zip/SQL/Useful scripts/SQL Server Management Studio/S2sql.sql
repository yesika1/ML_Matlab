/*Wall Clock SKU from Tariff Classification Audit. The first table shows all the items that crossed the border and had an EoiOktoSend = 1 
and the second table is all that 

select 
	EoiDateSent,
	EiiOpID,
	EiiRetailPrice,
	EiiQty,
	EiiPrSKU,
	EoiPONumSend,
	EiiName,
	EiiHSCode
	EoiDateSent
	
	
FROM csn_international..tblEDIOutItemIntl eii with(nolock)
join csn_international..tblEDIOutIntl eoi with(nolock) on eoi.EoiID = eii.EiiEoiID

WHERE EiiPrSKU in('ASTG5092')
and EoiOkToSend = '1';

select 
	EoiDateSent,
	EiiOpID,
	EiiRetailPrice,
	EiiQty,
	EiiPrSKU,
	EoiPONumSend,
	EiiName,
	EiiHSCode
	EoiDateSent
	
	
FROM csn_international..tblEDIOutItemIntl eii with(nolock)
join csn_international..tblEDIOutIntl eoi with(nolock) on eoi.EoiID = eii.EiiEoiID

WHERE EiiPrSKU in('ASTG5092')
--and EoiOkToSend = '1';