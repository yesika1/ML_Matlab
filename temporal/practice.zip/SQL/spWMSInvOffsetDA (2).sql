USE [csn_finance_wms]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- ==========================================================================================================================
-- Create date: 11/17/17
-- Description: PT 10955570.  This internal stored proc is used by the Data Quality team.
-- It will validate WMS offset requests, and insert offsets (if validated).

-- Change date: 07/11/2018
-- Description: PT 17696678.  Corrected issue for InvSource (for return costs) and InvVatCyID columns.
-- ==========================================================================================================================

ALTER PROCEDURE [dbo].[spWMSInvOffsetDA]
(
  @InvList NVARCHAR (MAX),
  @EmID INT,
  @UsID BIGINT = NULL,
  @TicketNumber INT,
  @Action INT = 0, -- 0 = preview, 1 = insert offsets
  @PaidDate DATETIME = NULL, -- Update to preferred date
  @AddtoVoucher BIT = 0 --Update to preferred setting
)

AS BEGIN

	DECLARE @Count INT = 0,
			@Beg INT = 1,
			@End INT = 10000,
			@ErrorMessage NVARCHAR(1000)

  SET NOCOUNT ON
  IF OBJECT_ID ('tempdb..#tInvoice') IS NOT NULL DROP TABLE #tInvoice

 CREATE TABLE #tInvoice (
		ID INT IDENTITY(1,1),
		xInvID INT PRIMARY KEY
  )

  INSERT INTO #tInvoice
  SELECT DISTINCT REPLACE (Value,' ','') AS xInvID
  FROM csn_product.dbo.SPLIT (@InvList,',') 
  SET NOCOUNT OFF

  SELECT @Count = COUNT(*)
  FROM #tInvoice 

   --Check for invalid InvIDs in temp table
 BEGIN
    IF EXISTS (SELECT t.xInvID FROM #tInvoice t WHERE t.xInvID NOT IN (SELECT inv.InvID FROM csn_wms.dbo.tbljoinStockPurchaseOrderReceiptInvoice inv WITH (NOLOCK)))
    BEGIN
    RAISERROR ('Your list of InvIDs contains at least one invalid value. Please check your list of InvIDs.', 16, 1)
    END
 END

  --Check if InvID has already been offset
  IF EXISTS (SELECT 1
			 FROM csn_wms.dbo.tbljoinStockPurchaseOrderReceiptInvoice inv WITH (NOLOCK)
			 INNER JOIN #tInvoice t ON t.xInvID = inv.InvID
			 WHERE inv.InvOffsetByInvID IS NOT NULL)
  BEGIN
    RAISERROR ('You cannot offset a InvID that has already been offset.',16,1)
    RETURN
  END

  --Check if selected InvPaidDate is within a locked period 
  IF EXISTS (SELECT 1
			 FROM csn_wms.dbo.tbljoinstockpurchaseOrderReceiptInvoice inv WITH (NOLOCK)
			 INNER JOIN #tInvoice t WITH (NOLOCK) ON t.xInvID = inv.InvID
			 LEFT JOIN csn_wms.dbo.tblStockPurchaseOrderItem spi WITH (NOLOCK) ON inv.InvSpiID = spi.SpiID
			 LEFT JOIN csn_wms.dbo.tblStockPurchaseOrder spo WITH (NOLOCK) ON spi.SpiSpoID = spo.SpoID
			 LEFT JOIN csn_wms.dbo.tblWMSSupplier ws WITH (NOLOCK) ON spo.SpoWHID = ws.WSWHID
			 LEFT JOIN csn_wms.dbo.tblWMSReconcileLOCK wl WITH (NOLOCK) ON wl.WMSStyID = ws.WSStyID
			 WHERE wl.WMSLockType = 'Inv Paid Date'
			 AND ((@PaidDate IS NOT NULL AND @PaidDate< DATEADD(D, 1, wl.WMSCutoffDate))
			 OR		(@PaidDate < DATEADD(D, 1, wl.WMSCutoffDate)))
			 )
 
  BEGIN
    RAISERROR ('The paid date you selected is locked to a pay period.', 16, 1)
    RETURN
  END

  --Preview Offsets
  IF @Action = 0

    BEGIN
       SELECT
	  xInvID AS OffsetInvID
	  , InvRcpID
	  , Invoice
	  , (-1 * InvQty) AS InvQty
	  , InvCostEach
	  , InvCostType
	  , InvAssocWith
	  , @PaidDate AS InvPaidDate
	  , @AddtoVoucher AS InvAddToVoucher
	  , NULL AS InvWvcID
	  , InvSpiID
	  , GETDATE() AS InvInvoiceDate
	  , GETDATE() AS InvCreateDate
	  , NULL AS InvLastModifiedDate
	  , NULL AS InvLastModifiedBy
	  , InvSuID
	  , NULL AS InvShipDate
	  , NULL AS InvShipVia
	  , NULL AS InvTrackingList
	  , ISNULL
			((CASE WHEN InvEntryType = 3 THEN
			(SELECT DISTINCT InvEntryType 
			 FROM csn_wms.dbo.tbljoinStockPurchaseOrderReceiptInvoice WITH (NOLOCK)
			 WHERE InvOffsetByInvID = InvID)
			 ELSE 3 END), 3)
		AS InvEntryType
	  , NULL AS InvAlwSaID
	  , NULL AS InvAlwOtherDesc
	  , NULL AS InvCreatedByWvcID
	  , ('OFF-' + REPLACE (CONVERT (VARCHAR ,GETDATE(), 102), '.', '') + '-' + REPLACE (CONVERT (VARCHAR , GETDATE(), 14), ':', '')) AS InvDataEntrySessionID
	  , NULL AS InvAlwTypeID
	  , InvTsID
	  , @EmID AS InvDataEntryEmID
	  , InvCuyID
	  , NULL AS InvOffsetByInvID
	  , InvAlwID
	  , InvCcoID
	  , NULL AS InvInvoiceSuffix
	  , InvAcID
	  , NULL AS InvWrtID
	  , InvBlcID
	  , NULL AS InvSlmBolNum
	  , NULL AS InvSposID
	  , NULL AS InvSplitFromInvID
	  , @EmID AS InvEmID
	  , CASE
			WHEN Invoice = 'Return to Wayfair' THEN InvSource
			ELSE 'PT ' + CAST(@TicketNumber AS VARCHAR)
			END AS InvSource
	  , @UsID AS InvUsID
	  , NULL AS InvWctID
	  , NULL AS InvWrcID
	  , NULL AS InvIsOvercharged
	  , NULL AS InvWrcLastUpdated
	  , InvCostCodeID
	  , InvCostCodeDetailID
	  , InvVatCyID
    FROM csn_wms.dbo.tbljoinStockPurchaseOrderReceiptInvoice inv WITH (NOLOCK)
    INNER JOIN #tInvoice t ON t.xInvID = inv.InvID
    WHERE t.xInvID <> ''
    END

  --Insert offsets into WMS Staging Loader
  ELSE IF @Action = 1

--This prevents execution in SSMS where rows would be inserted. 
--Adding a not like %dev% condition so that we can test the offsets in dev. 

  BEGIN

	IF SUSER_NAME() not like '%csn_dml_su%' AND @@SERVERNAME NOT LIKE '%dev%'
	BEGIN
	RAISERROR('Inserts can only be done in SQL Validator.',16,1)
	RETURN

  END

    BEGIN TRY
      BEGIN TRANSACTION

		DECLARE @BatchID INT
 
          INSERT INTO csn_wms.dbo.tblWMSInvoiceLineItemBatch 
		 ( BatDateCreated
		 , BatReadyToProcess
		 , BatProcessing
		 , BatDescription
		 , BatNumCosts
		 , BatTotalCost
		 )
          SELECT GETDATE() as BatDateCreated, 0 AS BatReadytoProcess, 0 AS BatProcessing, 'Offset' AS BatDescription, COUNT(1) AS BatNumCosts, SUM(InvCostEach * InvQty * -1) AS BatTotalCost
		  FROM csn_wms.dbo.tbljoinStockPurchaseOrderReceiptInvoice inv WITH (NOLOCK)
		  INNER JOIN #tInvoice t ON t.xInvID = inv.InvID
         
		  SELECT @BatchID = SCOPE_IDENTITY()
		 
		  WHILE @Beg <= @Count
		  BEGIN 
    
              INSERT INTO csn_wms.dbo.tblWMSInvoiceLineItemStagingDetail
              (BatchID
			  , OffsetsInvID
			  , InvRcpID
			  , Invoice
			  , InvQty
			  , InvCostEach
			  , InvCostType
			  , InvAssocWith
			  , InvSpiID
			  , InvInvoiceDate
			  , InvCreateDate
			  , InvSuID
			  , OffsetsDetailID
			  , InvEntryType
			  , InvTsID
			  , InvCuyID
			  , InvDataEntrySessionID
			  , InvDataEntryEmID
			  , InvBlcID
			  , InvAlwID
			  , InvCcoID
			  , InvCostCodeID
			  , InvCostCodeDetailID
			  , InvVatCyID
			  , InvAcID
			  , InvEmID
			  , InvSource
			  , InvUsID
			  , InvAddToVoucher
			  , InvPaidDate)
			  SELECT
			  @BatchID AS BatchID
			  , InvID
			  , InvRcpID
			  , Invoice
			  , -1 * InvQty AS InvQty
			  , InvCostEach
			  , InvCostType
			  , InvAssocWith
			  , InvSpiID
			  , GETDATE() AS InvInvoiceDate
			  , GETDATE() AS InvCreateDate
			  , InvSuID
			  , InvDetailID AS OffsetsDetailID
			  , ISNULL ((CASE WHEN InvEntryType = 3 THEN
                        (SELECT DISTINCT InvEntryType FROM csn_wms.dbo.tbljoinStockPurchaseOrderReceiptInvoice WITH (NOLOCK) 
					     WHERE InvOffsetByInvID = InvID)
                         ELSE 3 END), 3)
			    AS InvEntryType
			  , InvTsID
			  , InvCuyID
			  , ('OFF-' + REPLACE (CONVERT (VARCHAR ,GETDATE(), 102), '.', '') + '-' + REPLACE (CONVERT (VARCHAR , GETDATE(), 14), ':', ''))
			   AS InvDataEntrySessionID
			  , @EmID AS InvDataEntryEmID
			  , InvBlcID
			  , InvAlwID
			  , InvCcoID
			  , InvCostCodeID
			  , InvCostCodeDetailID
			  , InvVatCyID
			  , InvAcID
			  , @EmID AS InvEmID
			  , CASE
					WHEN Invoice = 'Return to Wayfair' THEN InvSource
					ELSE 'PT ' + CAST(@TicketNumber AS VARCHAR)
					END AS InvSource
			  , @UsID AS InvUsID
			  , @AddtoVoucher AS InvAddToVoucher
			  , @PaidDate AS InvPaidDate
			  FROM csn_wms.dbo.tbljoinStockPurchaseOrderReceiptInvoice inv WITH (NOLOCK)
			  INNER JOIN #tInvoice t ON t.xInvID = inv.InvID
			  WHERE t.ID BETWEEN @Beg AND @End

              SELECT @Beg = @Beg + 10000
              SELECT @End = @End + 10000

			  WAITFOR DELAY '00:00:02'

	   END

	   SET NOCOUNT ON
	   UPDATE csn_wms.dbo.tblWMSInvoiceLineItemBatch SET BatReadyToProcess = 1 WHERE BatID = @BatchID
	   SET NOCOUNT OFF
	   
	   COMMIT TRANSACTION

	  END TRY
	  
    BEGIN CATCH
      ROLLBACK TRANSACTION
      SELECT @ErrorMessage = 'Your insert has failed due to at least one error:' + ERROR_MESSAGE();
      RAISERROR (@ErrorMessage, 16, 1)
    END CATCH   
  END

END
;
;
;
GO
