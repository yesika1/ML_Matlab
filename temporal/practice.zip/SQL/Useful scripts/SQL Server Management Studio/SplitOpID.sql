declare @OpID_parent as bigint
set @OpID_parent =  2802310359
Select OpID, OpSplitfromOpID, * from csn_order.dbo.tblOrderProduct
Where OPID in (select opid from csn_order.dbo.tblOrderProduct op with (nolock) where opsplitfromopid=@OpID_parent)
Select OpID, OpSplitFromOpID, OpShipDate, OpPrPrice, OpPiCost, OpShipping, OpQty, ProductPrice, Adjustments, ProductDetailPromo, BrokerageFees, ShippingCost, Replacement, VFD, Currency, F_VFCC, F_VFDAMT, F_DutyAMT, F_Duty, DutyFee,EmbeddedDuty, DutyAMt, Variance
from csn_junk.dbo.FarrowOpSplit
Where OpSplitFromOpID = @OpID_parent
Select *
from csn_junk.dbo.tblFarrow
Where EiiOPID in (select opid from csn_order.dbo.tblOrderProduct op with (nolock) where opsplitfromopid=@OpID_parent)