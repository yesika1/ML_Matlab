select distinct  t.*, s.suname
from csn_product..tbljoinProductTreaty t (nolock)
left join csn_product..vwProductSupplierManufacturerPart p (nolock) on p.prsku = t.prsku
left join csn_product..tblsupplier s (nolock) on s.suid = p.supplierid
ORDER BY s.SuName;

select *
from csn_product..tbljoinProductTreaty with(nolock)
ORDER BY PrSKU ASC;