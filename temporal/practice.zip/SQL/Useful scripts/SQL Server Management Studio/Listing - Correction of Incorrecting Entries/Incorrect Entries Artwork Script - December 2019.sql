select
    o.OpID,
	o.OpPrSKU AS 'SKU',
	o.OpCurrentPoNum AS 'PO',
	--o.OpReCyId,--
	--o.OpReCountry,--
	od.OdPrName AS 'Product Name',
	o.OpShipDate,
	eoi.EoiDateSent,
	o.OpQty AS 'Qty',
	eii.EiiRetailPrice as 'VFD',
	eii.EiiHsCode AS 'HS Code',
	s.SuStyID,
	eoi.EoiExporterCountry AS 'Export Country',
	eoi.EoiSTCountry as 'Recipient Country'
	
		
from csn_product..tblOrderProduct o with(nolock)
join csn_order..tblOrderProductDetail od with(nolock) on o.OpID = od.OdOpID
join csn_order..tblSupplier s with (nolock) on o.OpSuID = s.SuID
join csn_international..tblEDIOutItemIntl eii with (nolock) on o.OpID=eii.EiiOpID
join csn_international..tblEDIOutIntl eoi with (nolock) on eoi.EoiID = eii.EiiEoiID

where (eoi.EoiDateSent BETWEEN '2017-01-01' AND '2019-12-31')
and o.OpPrSKU in ('DAN1392',
'EJH1138',
'NEWA1106',
'NST1627',
'OHN3140',
'FTGX1031')

and o.OpReCyId = '2'
and eoi.EoiOkToSend = '1'
and eoi.EoiExporterCountry = 'US'
and eoi.EoiSTCountry = 'CA'
and s.SuStyID = '1'
ORDER BY EiiOpID ASC;