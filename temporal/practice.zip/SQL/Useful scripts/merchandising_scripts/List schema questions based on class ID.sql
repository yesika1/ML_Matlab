/*
----------------------------------------------------------------------------------
LIST SCHEMA QUESTIONS BASED ON CLASS ID
----------------------------------------------------------------------------------
Use this script to pull all schema tags -STAG (questions) and their options-STAG title & MASTER_Stev Value (answers) based on class ID (CLID)
(just enter in the clid you want to pull the schema structure for)

-- Input: Product classID(ClID)
-- Output: table with all schema tags (questions) and their options (answers). Look for StagID (schema/attribute label) and stevID(level in schema)
           For instance: For Class: CLID 1318 Wall Art - Wall Art - GLOBAL, Schema: StagID 157233 Primary Art Material and Stag value, Level: StevID 221217 Canvas
-- Server: sqlBoadhoc

*/


----------------------------------------------------------------------------------
-- USER INPUT: classID (ClID)
----------------------------------------------------------------------------------
declare @classID as int
set @classID =  1318
; --Insert classID here, if need more than one class please add the list manually in the where clause


----------------------------------------------------------------------------------
-- MAIN QUERY
----------------------------------------------------------------------------------


/*
-- INPUT WORD TO OUTPUT RELATED CLASSES
select ClID,ClInternalRef,ClClgID 
from csn_product..tblClass (nolock)
where ClInternalRef like '%rug%'
*/


--To pull all schema tags (questions) and their options (answers) based on class id (just enter in the clid you want to pull the schema structure for):

SELECT DISTINCT c.CLID, 
 c.ClInternalRef,
--jm.MappingTypeID,
--pl.MappingType, 
st.StagID, st.StagTitle, 
case st.stagstprid when 0 then 'High Priority Required' when 1 then 'High Priority Not Required' when 2 then 'Low Priority' end as 'Priority Level', 
stev.StevID, stv.StvName,stev.StevValue AS [MASTER_StevValue],
CASE WHEN stev.StevActive = 0 THEN 'No' ELSE 'Yes' END AS [MASTER_StevActive],
sevd.seoddefinition as 'MASTER_StevValueDefinition',
ISNULL(gstevuk.GblStevValue,stev.StevValue) AS [UK_GblStevValue],
CASE
       WHEN gstuk.GblStagActive = 0 THEN 'TAG INACTIVE'
       WHEN gstevuk.GblStevActive = 1 THEN 'Yes'  
       WHEN gstevuk.GblStevActive = 0 THEN 'No'
       WHEN ISNULL(gstevuk.GblStevActive,stev.StevActive) = 0 THEN 'No'
       WHEN ISNULL(gstevuk.GblStevActive,stev.StevActive) = 1 THEN 'Yes'
       WHEN ISNULL(gstevuk.GblStevActive,ISNULL(stev.StevActive,1)) = 1 THEN 'Yes'
       ELSE '' END AS [UK_GblStevActive],
gsevduk.GblSeodDefinition as 'UK_GblStevValueDefinition',
ISNULL(gstevde.GblStevValue,stev.StevValue) AS [DE_GblStevValue],
CASE
       WHEN gstde.GblStagActive = 0 THEN 'TAG INACTIVE'
       WHEN gstevde.GblStevActive = 1 THEN 'Yes'
       WHEN gstevde.GblStevActive = 0 THEN 'No'
       WHEN ISNULL(gstevde.GblStevActive,stev.StevActive) = 0 THEN 'No'
       WHEN ISNULL(gstevde.GblStevActive,stev.StevActive) = 1 THEN 'Yes'
       WHEN ISNULL(gstevde.GblStevActive,ISNULL(stev.StevActive,1)) = 1 THEN 'Yes'
       ELSE '' END AS [DE_GblStevActive],
gsevdde.GblSeodDefinition as 'DE_GblStevValueDefinition'
,sevd.SeodID
--, gsevduk.GblSeodID, gsevdde.GblSeodID
FROM csn_product..tblSchemaTag st (NOLOCK)
LEFT OUTER JOIN csn_product..tblProdDescXMLSchema pdx (NOLOCK) ON pdx.PdxSchemaID = st.StagSchemaID
LEFT OUTER JOIN csn_product..tblClass c (NOLOCK) ON c.CLID = pdx.PdxCLID
LEFT OUTER JOIN csn_product..tblplSchemaTagValidation stv (NOLOCK) ON stv.StvID = st.StagStvID
LEFT OUTER JOIN csn_product..tblSchemaTagEnumValue stev (NOLOCK) ON stev.StevStagID = st.StagID
LEFT JOIN csn_product_global.dbo.tblGblSchemaTag gstuk WITH (NOLOCK) ON gstuk.GblBclgID = 2 AND gstuk.GblStagID = st.StagID
LEFT JOIN csn_product_global.dbo.tblGblSchemaTag gstde WITH (NOLOCK) ON gstde.GblBclgID = 3 AND gstde.GblStagID = st.StagID
LEFT JOIN csn_product_global.dbo.tblGblSchemaTagEnumValue gstevuk WITH (NOLOCK) ON gstevuk.GblBclgID = 2 AND gstevuk.GblStevID = stev.StevID
LEFT JOIN csn_product_global.dbo.tblGblSchemaTagEnumValue gstevde WITH (NOLOCK) ON gstevde.GblBclgID = 3 AND gstevde.GblStevID = stev.StevID
LEFT JOIN csn_product_cache.dbo.tbljoinDescriptionQuestionAttributeMappingType jm WITH(NOLOCK) ON QuestionID = StagID
LEFT JOIN csn_product_cache..tblplDescriptionMappingType pl WITH(NOLOCK) ON pl.MappingTypeID = jm.MappingTypeID
LEFT JOIN csn_product..tblSchemaEnumValueDefinition sevd on stev.StevID = sevd.SeodStevID
LEFT JOIN csn_product..tblGblSchemaEnumValueDefinition gsevduk WITH (NOLOCK) on gsevduk.GblBclgID = 2 AND gsevduk.GblSeodID = sevd.SeodID  
LEFT JOIN csn_product..tblGblSchemaEnumValueDefinition gsevdde WITH (NOLOCK) on gsevdde.GblBclgID = 3 AND gsevdde.GblSeodID = sevd.SeodID  

WHERE c.clid in (@classID)
-- WHERE c.clid in (197,198)
 
--AND (stev.StevActive != 0 OR stev.StevActive IS NULL)-- probabily is important? It should not have null values and the column may not being maintain.

--AND st.StagTitle in ('Type','Fabric Content')
--AND c.ClInternalRef LIKE '%Ottomans%'
--and st.stagid in ('13875','223410')
--and stev.StevValue like '%Polyester%'
--and stevid in ('11571','225685','225690','225699','594528','594531','594546','594530','594533','594536','594547','594539','594540','594538','594542')
--AND c.ClBclgID = 1 AND stv.StvID IN (5,6)
--AND gstuk.GblBclgID IS NOT NULL AND gstde.GblBclgID IS NOT NULL


ORDER BY c.CLID ASC,st.StagID ASC,stev.StevID ASC
 