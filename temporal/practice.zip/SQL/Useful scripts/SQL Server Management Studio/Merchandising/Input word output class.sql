select ClId, ClName, ClInternalRef
from
csn_product..tblclass with (nolock)
where ClInternalRef like '%wall art%'
and ClInternalRef not like '%DO NOT USE%'

--1318--