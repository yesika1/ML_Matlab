/*
Ocean carrier -- container info
Script adding BOL#  
server: SQLREPORTING01
*/

SELECT
distinct 
SpoID as 'SPO',
gateinoriginport as "Wharf Gated In",
emptycontainerreturn_master as 'Empty Container Returned',
SpoInboundServiceLevelName as 'Service Level',
Suppliername as 'Supplier Name',
ContainerNumber as 'Container No.',
LiBOLNumber as 'BOL No.', 
OceanCarrierName as 'Ocean Carrier',
DrayCarrierName as 'Dray Carrier',
OriginPortCode as 'Origin Port',
case when Originportcode = 'CNFZG' then 'China'
when Originportcode = 'CNFZH' then 'China'
when Originportcode = 'CNYTN' then 'China'
when Originportcode = 'CNSHG' then 'China'
when Originportcode = 'CNTAZ' then 'China'
when Originportcode = 'CNNBG' then 'China'
when Originportcode = 'CNTXG' then 'China'
when Originportcode = 'CNTYN' then 'China'
when Originportcode = 'CNWHG' then 'China'
when Originportcode = 'CNXAO' then 'China'
when Originportcode = 'CNXMG' then 'China'
when Originportcode = 'CNZPU' then 'China'
when Originportcode = 'CNZSN' then 'China'
when Originportcode = 'IDJKT' then 'Indonesia'
when Originportcode = 'IDSRG' then 'Indonesia'
when Originportcode = 'IDSUB' then 'Indonesia'
when Originportcode = 'INMUN' then 'India'
when Originportcode = 'INNSA' then 'India'
when Originportcode = 'MYPEN' then 'Malaysia'
when Originportcode = 'MYPGU' then 'Malaysia'
when Originportcode = 'MYPKG' then 'Malaysia'
when Originportcode = 'MYTPP' then 'Malaysia'
when Originportcode = 'THLCH' then 'Thailand'
when Originportcode = 'TWKHH' then 'Taiwan'
when Originportcode = 'TWTXG' then 'Taiwan'
when Originportcode = 'VNDAD' then 'Vietnam'
when Originportcode = 'VNIPH' then 'Vietnam'
when Originportcode = 'VNDNA' then 'Vietnam'
when Originportcode = 'VNSGN' then 'Vietnam'
when Originportcode = 'VNUIH' then 'Vietnam'
else 'Other'
end as 'Origin Country',
DestinationPortCode as 'Desination Port',
case when DestinationPortCode = 'USNYC' then 'US (EC)'
when DestinationPortCode = 'USSAV' then 'US (EC)'
when DestinationPortCode = 'USOAK' then 'US (WC)'
when DestinationPortCode = 'USORF' then 'US (EC)'
when DestinationPortCode = 'USLGB' then 'US (WC)'
when DestinationPortCode = 'USLAX' then 'US (WC)'
when DestinationPortCode = 'USJAX' then 'US (EC)'
when DestinationPortCode = 'USEWR' then 'US (EC)'
when DestinationPortCode = 'USDAL' then 'US (EC/WC)'
when DestinationPortCode = 'USCVG' then 'US (EC)'
when DestinationPortCode = 'GBSOU' then 'UK'
when DestinationPortCode = 'DEHAM' then 'Germany'
when DestinationPortCode = 'DEBRV' then 'Germany'
when DestinationPortCode = 'CATOR' then 'Canada'
else 'Other'
end as 'Destination Country',
DestinationWarehouse as 'Dest. Warehouse',
ContainerNumber as 'Container No.',
case when IsPrePull = '1' then 'Yes'
when IsPrePull = '0' then 'No'
else 'Other'
end as 'Pre-Pull'

FROM 
csn_export_scl.dbo.tblISCDatamart with (nolock)
left join csn_invoice.dbo.tblLoadInvoice a with(nolock) on LiPONumber = SpoID
left join csn_invoice.dbo.tblLoadInvoiceItem b with(nolock) on a.[LiID] = b.[IiLiID]
--left join csn_reporting_isc.dbo.tblInboundSPOMilestones with (nolock) on LiPONumber = SpoID

WHERE 
spoiscancelled = 0 
and [LiTsID] in ('562','725','999','1150','1152','1151', '1153', '1155', '544','695','790','934','944')
and IiUnitPrice <> '0'
--and LiDateLoaded between '2020-03-23' and '2020-04-05'
--and LiPONumber = 'WHS-3026-5754265'
and SpoID = 'WHS-3026-5754265'