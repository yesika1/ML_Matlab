
SELECT EiiEoiID,EiiQty,EiiPrSKU,EiiMaName,EiiHsCode,EoiPONum,EoiPONumSend,EoiPODate
from csn_international..tblEDIOutItemIntl a with (nolock)
join csn_international..tblEDIOutIntl b with (nolock) on EoiID=EiiEoiID
where EoiOkToSend = '1'
and EoiPONum in (
'146581099',
'142617053')
