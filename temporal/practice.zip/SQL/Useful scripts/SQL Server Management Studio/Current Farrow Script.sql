select DISTINCT Top 5
	e.EoiID,
	i.Eii
	e.EoiDateSent,
	e.EoiSupplierName,
	e.EoiSupplierCountry,
	e.EoiSTCountry,
	e.EoiSTCyID,
	hs.HsCyId

from csn_international.dbo.tblEDIOutIntl e with(nolock)
join csn_product..tblHSCodeCountry hs with (nolock) on e.EoiSTCyID = hs.HsCyId
join csn_international.dbo.tblEDIOutItemIntl i with(nolock) on e.EoiID = i.EiiEoiId
where e.EoiSTCountry = 'Canada' and e.EoiDateSent BETWEEN '2019-09-01' AND '2019-09-30';