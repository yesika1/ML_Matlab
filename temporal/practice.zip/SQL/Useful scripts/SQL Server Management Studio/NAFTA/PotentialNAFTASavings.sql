IF OBJECT_ID('tempdb.dbo.#part') IS NOT NULL DROP TABLE #part
select DISTINCT c.ManufacturerPartID, a.SupplierID, a.SupplierPartNumber
into #part
from csn_product..tblSupplierPart a with (nolock)
left outer join csn_product..tblOptionCombination c with (nolock) on a.ManufacturerPartID=c.ManufacturerPartID
where exists (select top 1 1 from csn_product..tbljoinProductTreaty t with(nolock) where c.prsku = t.PrSKU)
--pulling in the cloned versions of a SKU. 

IF OBJECT_ID('tempdb.dbo.#allv') IS NOT NULL DROP TABLE #allv
select distinct-- p.prsku, p.supplierpartnumber, p.SupplierID,
c.PrSKU as 'AllSKUs'
--, PrStatusName, COALESCE (acsdescription,drdescription) as 'Status Reason'
into #ALLV
from #part p (nolock)
join csn_product..tblSupplierPart a with (nolock) on p.SupplierPartNumber = a.SupplierPartNumber and p.SupplierID = a.SupplierID
inner join csn_product..tblOptionCombination c with (nolock) on a.ManufacturerPartID=c.ManufacturerPartID


select distinct
	op.opprsku,
	OpSuID,
	eiiOpId,
	isnull(s.suparentsuid, S.suid) [SuID],
	eoii.eiiname AS 'Product Name',
	eiiQty,
	eoiSupplierName,
	OcAmount,
	OcDescription,
	eoi.EoiDateSent,
	eoiExporterCountry,
	eoi.EoiSTCountry,
	jpt.tryid,
	jpt.effectivedate
from
csn_order..tblorderproduct op (nolock)
join csn_international..tblEDIOutItemIntl eoii with (nolock) on eoii.eiiopid=op.OpId
join csn_international..tblEDIOutIntl eoi with (nolock) on eoii.eiieoiid = eoi.eoiid
left join csn_cost..tblordercost oc with (nolock) on op.opID = oc.ocopid
left join csn_product..tbljoinProductTreaty jpt with (nolock) on op.opPrSKU=jpt.PrSku
left join csn_product..tblsupplier s with (nolock) on op.OpSuID = s.SuID
left join csn_product..tblproduct p with (nolock) on op.opprsku = p.prsku

where
eoi.EoiDateSent >= '2019-09-01' 
and eoi.EoiDateSent < '2019-10-01'
and EoiSTCountry ='CA'
and EoiOkToSend ='1'
and EoiExporterCountry = 'US'
and OcDescription = 'Duty'
and PrCyId in ('1', '2', '143')
and isnull(s.suparentsuid, S.suid) not in (21028,2826,7347,20613,1664,6180,83,17301,1748,8430,15784,15231,421,12048,14785,5489,19553,15817,7141,2022,31095,8595,203,308,3215,13552,11377,39237,12430,26281)
AND NOT EXISTS (SELECT TOP 1 1 FROM #allv WHERE op.opprsku = allskus)
--ORDER by eoi.EoiDateSent ASC;
ORDER BY EoiSupplierName ASC;