Procedure

1. use the script: INPUT WORD OUTPUT RELATED CLASSES
to obtain the product classes list (clID)

2. use the script: LIST SCHEMA QUESTIONS BASED ON CLASS ID
to input the class and obtain the list of product schema (attributes)
transfer output to excel and filter given the attributes required and saved the stagID

3. use the script: canvas product types.sql
to retrive a list of product SKU that can contain a specific stag type given the product classID (CLID) 
& Schema(StagID) selected

4. use the script: Product Web Descriptions
to obtain a list of sku give the product name (prname) and description (PgenValue) key words.

5. Use the script: CA sales and merch SQL.sql 
to obtain EDI information sent to farrow




