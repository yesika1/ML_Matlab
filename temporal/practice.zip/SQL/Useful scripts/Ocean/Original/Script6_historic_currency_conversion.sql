/*
Script 6: Historic Currency Conversion

This script pulls currency conversion rates given a date range.						

Database:	SQLREPORTING01				
Updated:	4/24/20	12:41 PM
*/				
-------------------------------------------------------------------------------							
Declare @startdate smalldatetime							
SET  @startdate = '2020-02-02 00:00:00'			-- Start time of day invoiced				
Declare @enddate smalldatetime							
set @enddate  = '2020-02-02 23:59:00'			-- End time of day invoiced			

------------
						
Drop table if exists #USDtoCAD							
SELECT							
CerFromCuyID							
,CerToCuyID							
,CerExchangeRate							
,CerEffectiveDate							
into #USDtoCAD							
FROM csn_exchangerates.dbo.tblCurrencyExchangeRateHist WITH (NOLOCK)							
where cerfromcuyid = 'USD'							
and CERTOCUYID = 'CAD' --Canadian Dollar							

Drop table if exists #CADtoUSD							
Select							
CerFromCuyID							
,CerToCuyID							
,CerExchangeRate							
,CerEffectiveDate							
into #CADtoUSD							
FROM csn_exchangerates.dbo.tblCurrencyExchangeRateHist WITH (NOLOCK)							
where cerfromcuyid = 'CAD'							
and CERTOCUYID = 'USD' --Canadian Dollar							
Drop table if exists #USDtoGBP							
SELECT							
CerFromCuyID							
,CerToCuyID							
,CerExchangeRate							
,CerEffectiveDate							
into #USDtoGBP							
FROM csn_exchangerates.dbo.tblCurrencyExchangeRateHist WITH (NOLOCK)							
where cerfromcuyid = 'USD'							
and CERTOCUYID = 'GBP' --UK Pound							
Drop table if exists #GBPtoUSD							
SELECT CerFromCuyID							
,CerToCuyID							
,CerExchangeRate							
,CerEffectiveDate							
into #GBPtoUSD							
FROM csn_exchangerates.dbo.tblCurrencyExchangeRateHist WITH (NOLOCK)							
where CerFromCuyID = 'GBP'							
and CerToCuyID = 'USD'	
					
Drop table if exists #USDtoEUR							
SELECT							
CerFromCuyID							
,CerToCuyID							
,CerExchangeRate							
,CerEffectiveDate							
into #USDtoEUR							
FROM csn_exchangerates.dbo.tblCurrencyExchangeRateHist WITH (NOLOCK)							
where cerfromcuyid = 'USD'							
and CERTOCUYID = 'EUR' --EURO							


Drop table if exists #EURtoUSD							
SELECT							
CerFromCuyID							
,CerToCuyID							
,CerExchangeRate							
,CerEffectiveDate							
into #EURtoUSD							
FROM csn_exchangerates.dbo.tblCurrencyExchangeRateHist WITH (NOLOCK)							
where cerfromcuyid = 'EUR'							
and CERTOCUYID = 'USD'	
						

Select * from #USDtoCAD							
where							
CerEffectiveDate>= @startdate							
and							
CerEffectiveDate <= @enddate

union							
select * from #USDtoEUR							
where							
CerEffectiveDate>= @startdate							
and							
CerEffectiveDate <= @enddate							

union							
select * from #USDtoGBP							
where							
CerEffectiveDate>= @startdate							
and							
CerEffectiveDate <= @enddate

/*
union							
select * from #CADtoUSD							
where							
CerEffectiveDate>= @startdate							
and							
CerEffectiveDate <= @enddate								
						
union							
select * from #GBPtoUSD							
where							
CerEffectiveDate>= @startdate							
and							
CerEffectiveDate <= @enddate							
					
union							
select * from #EURtoUSD							
where							
CerEffectiveDate>= @startdate							
and							
CerEffectiveDate <= @enddate							
*/		
				
