select   COLUMN_NAME, DATA_TYPE 

FROM INFORMATION_SCHEMA.COLUMNS (nolock)
where
TABLE_NAME =  'tblOrderproduct' 
--TABLE_NAME =  'csn_order.dbo.tblOrderproduct'

SELECT * FROM INFORMATION_SCHEMA.COLUMNS