select p.prSKU, p.PrName, c.CyLongName as 'CountryOfOrigin', hs.HsCyId, tphs.TARIFF, tphs.MFN as 'MFNDutyRate', jpt.TryID
from csn_product..tblproduct p with (nolock)
join csn_product..tblplcountry c with (nolock) on p.PrCyId = c.CyID
join csn_product..tblHSCodeCountry hs with (nolock) on p.PrSKU=hs.HsPrSKU
join csn_shiprates..tphs tphs with (nolock) on p.PrHsCodeBase = tphs.HSCodeBase and hs.HsCodeCountry=tphs.HSCountryCode
left join csn_product..tbljoinProductTreaty jpt with (nolock) on p.PrSKU=jpt.PrSku
where hs.HsCyId=2
and p.prSKU in ('ASTG5092',
'HW1383',
'HEF1138',
'UH1847',
'YDCR1135',
'BCHH8112',
'OAWY2985',
'ASTG5092',
'GDRD1001') 