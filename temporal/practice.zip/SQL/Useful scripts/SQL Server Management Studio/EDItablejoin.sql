select *
from csn_international..tblEDIOutItemIntl eii with(nolock)
join csn_international..tblEDIOutIntl eoi with(nolock) on eii.EiiEoiID = eoi.EoiID
where EiiOpID ='2556073321'
and EiiPrSKU = 'ESIG1148'
and EoiOkToSend = '1'