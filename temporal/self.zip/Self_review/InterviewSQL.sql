USE csn_junk
RETURN
--CREATE TABLE csn_junk.dbo.JOE_Cost (CostID INT IDENTITY(1,1) PRIMARY KEY CLUSTERED, CostTypeID INT, CostAmount MONEY)
--CREATE TABLE csn_junk.dbo.JOE_plCostType (CostTypeID INT IDENTITY(1,1) PRIMARY KEY CLUSTERED, TypeName nvarchar(55))
/*
	INSERT INTO csn_junk.dbo.JOE_Cost
	VALUES (1,150), (2,2.10),  (1,-50),  (2,10),  (2, -.02),  (2,10),  (NULL,10),  (1,10), (1,1530), (1,205), (1,200)

	
	INSERT INTO csn_junk.dbo.JOE_plCostType (TypeName)
	VALUES ('Product') , ('Shipping')

*/

SELECT *
FROM csn_junk.dbo.JOE_plCostType 

SELECT *
FROM csn_junk.dbo.JOE_Cost

-- find the total in JOE_Cost
-- find total where type is 1
-- find total and return a column indicating what the type is
-- use the _pl table to return the nvarchar name of the cost type rather then the integer
-- exclude "rare" costs (threshold of 4 or less)

