select 
	p.PrSKU,
	--p.PrName
	o.OpQty,
	o.OpShipDate
	--eii.EiiRetailPrice as 'VFD'
	--eoi.EoiSupplierName as 'Supplier'
	--s.SuName
	--eii.EiiNafta
	
from csn_order..tblproduct p with(nolock)
join csn_product.dbo.tblOrderProduct o with (nolock) on p.PrSKU = o.OpPrSKU
join csn_product..tblJoinProductSupplier ps with (nolock) on p.PrSKU = ps.PrSKU
join csn_international..tblEDIOutItemIntl eii with (nolock) on p.PrSKU = eii.EiiPrSKU
--join csn_international..tblEDIOutIntl eoi with(nolock) on eoi.EoiID = eii.EiiEoiID
--join csn_product..tblJoinProductSupplier ps with (nolock) on ps.PrSKU = p.PrSKU
--join csn_order..tblSupplier s with(nolock) on s.SuID = ps.SuID
--join csn_product.dbo.tblOrderProductDetail pd with (nolock) on o.OpID = pd.OdOpID

where (o.OpShipDate BETWEEN '2019-09-01' AND '2019-09-30')
and o.OpReCyID = '2'
and o.OpPrPrice > 1
ORDER BY o.OpShipDate ASC;


--and s.SuStyID = '1'
--and eoi.EoiOkToSend= '1'
--and eii.EiiNafta = NULL


